# 🌤 هواشناسی ایران - Full Stack

پروژه پیش‌بینی آب و هوای شهرهای ایران با **Django REST Framework** و **Next.js 14**.

## 🏗 معماری

```
weather-fullstack/
├── backend/          # Django + DRF (API)
│   ├── core/         # تنظیمات اصلی پروژه
│   ├── weather/      # اپلیکیشن آب و هوا
│   ├── templates/    # تمپلیت‌ها
│   ├── .env          # متغیرهای محیطی
│   └── manage.py
└── frontend/         # Next.js 14 (App Router)
    ├── app/          # ۴ صفحه
    ├── components/   # کامپوننت‌ها
    └── public/       # فایل‌های استاتیک
```

## 🚀 راه‌اندازی

### ۱. بک‌اند

```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt

# کپی .env.example به .env و ویرایش
# cp .env.example .env

python manage.py migrate
python manage.py seed_provinces
python manage.py runserver
```

### ۲. فرانت‌اند

```bash
cd frontend
npm install
npm run dev
```

> **نکته:** فایل `map.jpg` رو از پروژه قبلی به `frontend/public/` کپی کنید.

## 📄 صفحات

| صفحه | مسیر | توضیحات |
|------|------|---------|
| داشبورد | `/` | صفحه اصلی با نقشه و جستجو |
| جزئیات شهر | `/city/[name]` | اطلاعات کامل یک شهر |
| پیش‌بینی | `/forecast` | پیش‌بینی ۵ روزه |
| استان‌ها | `/provinces` | لیست استان‌ها و شهرها |

## 🔌 API Endpoints

| Endpoint | Method | توضیحات |
|----------|--------|---------|
| `/api/provinces/` | GET | لیست استان‌ها |
| `/api/cities/{name}/weather/` | GET | آب و هوای فعلی |
| `/api/cities/{name}/forecast/` | GET | پیش‌بینی ۵ روزه |
| `/api/provinces/{id}/weather/` | GET | آب و هوای مرکز استان |

## ⚙️ متغیرهای محیطی (.env)

```env
SECRET_KEY=your-secret-key
DEBUG=True
OPENWEATHER_API_KEY=your-api-key
```

## 📝 نکات

- کلید API رایگان OpenWeatherMap از [اینجا](https://openweathermap.org/api) بگیر
- CORS برای `localhost:3000` فعاله
- کش آب و هوا ۱۰ دقیقه‌ایه
- فایل `.env` رو **هرگز** کامیت نکن!
