'use client';
import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import SearchBar from '@/components/SearchBar';
import WeatherCard from '@/components/WeatherCard';
import QuickInfo from '@/components/QuickInfo';
import IranMap from '@/components/IranMap';
import ProvincesList from '@/components/ProvincesList';
import Forecast from '@/components/Forecast';
import HourlyForecast from '@/components/HourlyForecast';
import ExtraInfo from '@/components/ExtraInfo';
import { fetchCityWeather, fetchCityForecast, fetchProvinces } from '@/lib/api';

export default function Home() {
  const [city, setCity] = useState('تهران');
  const [province, setProvince] = useState(null);
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState('dark');
  const [provinces, setProvinces] = useState([]);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  useEffect(() => {
    fetchProvinces().then(data => {
      setProvinces(data);
      const tehran = data.find(p => p.capital === 'تهران');
      setProvince(tehran);
    });
  }, []);

  useEffect(() => {
    if (!city) return;
    setLoading(true);
    Promise.all([fetchCityWeather(city), fetchCityForecast(city)])
      .then(([w, f]) => {
        w.name = city;
        setWeather(w);
        setForecast(f.list);
      })
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  }, [city]);

  const handleSelectCity = (newCity, newProvince) => {
    setCity(newCity);
    setProvince(newProvince);
  };

  return (
    <div className="pb-10">
      <Header theme={theme} onToggleTheme={() => setTheme(t => t === 'dark' ? 'light' : 'dark')} />
      <main className="max-w-7xl mx-auto px-4 py-6">
        <SearchBar provinces={provinces} onSelectCity={handleSelectCity} />
        <section className="mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <WeatherCard weather={weather} province={province} loading={loading} />
            </div>
            <QuickInfo weather={weather} loading={loading} />
          </div>
        </section>
        <section className="mb-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <IranMap provinces={provinces} currentCity={city} onSelectCity={handleSelectCity} />
          </div>
          <ProvincesList provinces={provinces} currentCity={city} onSelectCity={handleSelectCity} />
        </section>
        <Forecast forecast={forecast} loading={loading} />
        <HourlyForecast forecast={forecast} loading={loading} />
        <ExtraInfo weather={weather} loading={loading} />
      </main>
    </div>
  );
}
