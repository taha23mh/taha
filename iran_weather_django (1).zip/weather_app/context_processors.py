from .utils import PROVINCES_DATA
from django.utils import timezone


def provinces_data_processor(request):
    return {
        'provinces_data': PROVINCES_DATA,
    }
