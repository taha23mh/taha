"""Utility functions for weather data processing."""

import requests
from django.conf import settings

PROVINCES_DATA = [
    {"id": 1, "name": "آذربایجان شرقی", "capital": "تبریز", "cities": ["تبریز","مراغه","میانه","بناب","اهر","سراب","مرند","شبستر"], "x": 10, "y": 11, "lat": 38.08},
    {"id": 2, "name": "آذربایجان غربی", "capital": "ارومیه", "cities": ["ارومیه","خوی","سلماس","ماکو","مهاباد","بوکان","نقده","پیرانشهر"], "x": 12, "y": 20, "lat": 37.55},
    {"id": 3, "name": "اردبیل", "capital": "اردبیل", "cities": ["اردبیل","پارس‌آباد","مشگین‌شهر","خلخال","گرمی","بیله‌سوار"], "x": 20, "y": 14, "lat": 38.25},
    {"id": 4, "name": "اصفهان", "capital": "اصفهان", "cities": ["اصفهان","کاشان","نائین","نجف‌آباد","شاهین‌شهر","فولادشهر","زرین‌شهر"], "x": 48, "y": 40, "lat": 32.65},
    {"id": 5, "name": "البرز", "capital": "کرج", "cities": ["کرج","نظرآباد","اشتهارد","فردیس","محمدشهر","هشتگرد","ماهدشت"], "x": 35, "y": 29, "lat": 35.92},
    {"id": 6, "name": "ایلام", "capital": "ایلام", "cities": ["ایلام","دهلران","آبدانان","مهران","ایوان","دره‌شهر","آسمان‌آباد"], "x": 13, "y": 44, "lat": 33.64},
    {"id": 7, "name": "بوشهر", "capital": "بوشهر", "cities": ["بوشهر","برازجان","گناوه","خارک","دیلم","کنگان","جم","عسلویه"], "x": 35, "y": 72, "lat": 28.95},
    {"id": 8, "name": "تهران", "capital": "تهران", "cities": ["تهران","ورامین","شهریار","پاکدشت","رباط‌کریم","اسلام‌شهر","قدس","ملارد"], "x": 40, "y": 30, "lat": 35.69},
    {"id": 9, "name": "چهارمحال و بختیاری", "capital": "شهرکرد", "cities": ["شهرکرد","فارسان","بروجن","لردگان","سامان","اردل","بن","کوهرنگ"], "x": 35, "y": 53, "lat": 32.33},
    {"id": 10, "name": "خراسان جنوبی", "capital": "بیرجند", "cities": ["بیرجند","قاین","فردوس","نهبندان","طبس","سرایان","خوسف"], "x": 73, "y": 48, "lat": 32.87},
    {"id": 11, "name": "خراسان رضوی", "capital": "مشهد", "cities": ["مشهد","نیشابور","سبزوار","تربت حیدریه","کاشمر","تربت جام","چناران","قوچان"], "x": 73, "y": 25, "lat": 36.30},
    {"id": 12, "name": "خراسان شمالی", "capital": "بجنورد", "cities": ["بجنورد","اسفراین","شیروان","آشخانه","جاجرم","پیش‌قلعه"], "x": 64, "y": 18, "lat": 37.47},
    {"id": 13, "name": "خوزستان", "capital": "اهواز", "cities": ["اهواز","آبادان","خرمشهر","دزفول","مسجدسلیمان","بهبهان","اندیمشک","شوشتر"], "x": 25, "y": 56, "lat": 31.32},
    {"id": 14, "name": "زنجان", "capital": "زنجان", "cities": ["زنجان","ابهر","خرمدره","قیدار","طارم","ماه‌نشان","سلطانیه"], "x": 20, "y": 25, "lat": 36.67},
    {"id": 15, "name": "سمنان", "capital": "سمنان", "cities": ["سمنان","شاهرود","دامغان","گرمسار","مهدی‌شهر","ایوانکی"], "x": 58, "y": 30, "lat": 35.58},
    {"id": 16, "name": "سیستان و بلوچستان", "capital": "زاهدان", "cities": ["زاهدان","زابل","چابهار","ایرانشهر","خاش","سراوان","نیک‌شهر","کنارک"], "x": 80, "y": 80, "lat": 29.50},
    {"id": 17, "name": "فارس", "capital": "شیراز", "cities": ["شیراز","مرودشت","جهرم","کازرون","فسا","داراب","لار","استهبان"], "x": 45, "y": 66, "lat": 29.62},
    {"id": 18, "name": "قزوین", "capital": "قزوین", "cities": ["قزوین","تاکستان","آبیک","بوئین‌زهرا","محمدیه","الوند","محمودآباد نمونه"], "x": 28, "y": 28, "lat": 36.27},
    {"id": 19, "name": "قم", "capital": "قم", "cities": ["قم","قنوات","کهک","جعفریه","سلفچگان"], "x": 35, "y": 35, "lat": 34.65},
    {"id": 20, "name": "کردستان", "capital": "سنندج", "cities": ["سنندج","مریوان","سقز","بانه","قروه","بیجار","دیواندره","کامیاران"], "x": 15, "y": 28, "lat": 35.31},
    {"id": 21, "name": "کرمان", "capital": "کرمان", "cities": ["کرمان","سیرجان","رفسنجان","جیرفت","بم","زرند","بافت","کهنوج"], "x": 65, "y": 63, "lat": 30.28},
    {"id": 22, "name": "کرمانشاه", "capital": "کرمانشاه", "cities": ["کرمانشاه","اسلام‌آباد غرب","سنقر","صحنه","هرسین","کنگاور","صاحب","قصر شیرین"], "x": 13, "y": 35, "lat": 34.32},
    {"id": 23, "name": "کهگیلویه و بویراحمد", "capital": "یاسوج", "cities": ["یاسوج","گچساران","دهدشت","سی‌سخت","لیکک","چرام","باشت"], "x": 38, "y": 61, "lat": 30.67},
    {"id": 24, "name": "گلستان", "capital": "گرگان", "cities": ["گرگان","گنبد کاووس","آق‌قلا","بندر ترکمن","علی‌آباد کتول","کلاله","مینودشت","آزادشهر"], "x": 55, "y": 18, "lat": 36.85},
    {"id": 25, "name": "گیلان", "capital": "رشت", "cities": ["رشت","بندر انزلی","لاهیجان","صومعه‌سرا","رودبار","آستارا","تالش","لنگرود"], "x": 30, "y": 22, "lat": 37.28},
    {"id": 26, "name": "لرستان", "capital": "خرم‌آباد", "cities": ["خرم‌آباد","بروجرد","دورود","الیگودرز","کوهدشت","ازنا","الشتر","نورآباد"], "x": 25, "y": 47, "lat": 33.49},
    {"id": 27, "name": "مازندران", "capital": "ساری", "cities": ["ساری","بابل","آمل","قائم‌شهر","نوشهر","تنکابن","بهشهر","نکا"], "x": 43, "y": 23, "lat": 36.56},
    {"id": 28, "name": "مرکزی", "capital": "اراک", "cities": ["اراک","ساوه","خمین","محلات","تفرش","دلیجان","آشتیان","شازند"], "x": 28, "y": 38, "lat": 34.10},
    {"id": 29, "name": "هرمزگان", "capital": "بندرعباس", "cities": ["بندرعباس","میناب","قشم","بندر لنگه","کیش","حاجی‌آباد","رودان","بستک"], "x": 58, "y": 82, "lat": 27.18},
    {"id": 30, "name": "همدان", "capital": "همدان", "cities": ["همدان","نهاوند","ملایر","تویسرکان","اسدآباد","بهار","کبودرآهنگ","رزن"], "x": 22, "y": 34, "lat": 34.80},
    {"id": 31, "name": "یزد", "capital": "یزد", "cities": ["یزد","میبد","اردکان","بافق","تفت","مهریز","ابرکوه","خاتم"], "x": 58, "y": 52, "lat": 31.90},
]

WEATHER_TYPES = {
    '01d': {'name': 'آفتابی', 'icon': 'fa-sun', 'color': '#f5b942'},
    '01n': {'name': 'آفتابی', 'icon': 'fa-sun', 'color': '#f5b942'},
    '02d': {'name': 'نیمه ابری', 'icon': 'fa-cloud-sun', 'color': '#9bb8d9'},
    '02n': {'name': 'نیمه ابری', 'icon': 'fa-cloud-moon', 'color': '#9bb8d9'},
    '03d': {'name': 'ابری', 'icon': 'fa-cloud', 'color': '#8b92b8'},
    '03n': {'name': 'ابری', 'icon': 'fa-cloud', 'color': '#8b92b8'},
    '04d': {'name': 'ابری', 'icon': 'fa-cloud', 'color': '#8b92b8'},
    '04n': {'name': 'ابری', 'icon': 'fa-cloud', 'color': '#8b92b8'},
    '09d': {'name': 'بارانی', 'icon': 'fa-cloud-rain', 'color': '#4fc3f7'},
    '09n': {'name': 'بارانی', 'icon': 'fa-cloud-rain', 'color': '#4fc3f7'},
    '10d': {'name': 'بارانی', 'icon': 'fa-cloud-rain', 'color': '#4fc3f7'},
    '10n': {'name': 'بارانی', 'icon': 'fa-cloud-moon-rain', 'color': '#4fc3f7'},
    '11d': {'name': 'رعد و برق', 'icon': 'fa-cloud-bolt', 'color': '#9b6dff'},
    '11n': {'name': 'رعد و برق', 'icon': 'fa-cloud-bolt', 'color': '#9b6dff'},
    '13d': {'name': 'برفی', 'icon': 'fa-snowflake', 'color': '#e0f4ff'},
    '13n': {'name': 'برفی', 'icon': 'fa-snowflake', 'color': '#e0f4ff'},
    '50d': {'name': 'مه‌آلود', 'icon': 'fa-smog', 'color': '#b8bfd9'},
    '50n': {'name': 'مه‌آلود', 'icon': 'fa-smog', 'color': '#b8bfd9'},
}

WIND_DIRECTIONS = ['شمال', 'شمال شرق', 'شرق', 'جنوب شرق', 'جنوب', 'جنوب غرب', 'غرب', 'شمال غرب']
DAY_NAMES = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه']


def to_persian_num(num):
    return str(num).replace('0', '۰').replace('1', '۱').replace('2', '۲').replace('3', '۳').replace('4', '۴').replace('5', '۵').replace('6', '۶').replace('7', '۷').replace('8', '۸').replace('9', '۹')


def normalize_fa(text):
    return text.replace('ي', 'ی').replace('ك', 'ک').replace('أ', 'ا').replace('إ', 'ا').replace('ؤ', 'و').replace('ئ', 'ی')


def get_weather_type(icon_code):
    return WEATHER_TYPES.get(icon_code, WEATHER_TYPES['01d'])


def deg_to_compass(deg):
    val = int((deg / 45) + 0.5)
    return WIND_DIRECTIONS[val % 8]


def get_province_by_capital(capital):
    for p in PROVINCES_DATA:
        if p['capital'] == capital:
            return p
    return PROVINCES_DATA[7]


def search_provinces(query):
    if not query:
        return []
    nq = normalize_fa(query.strip())
    results = []
    for p in PROVINCES_DATA:
        if normalize_fa(p['name']).find(nq) != -1 or normalize_fa(p['capital']).find(nq) != -1:
            results.append({'city': p['capital'], 'province': p, 'is_capital': True})
        for c in p['cities']:
            if normalize_fa(c).find(nq) != -1 and c != p['capital']:
                results.append({'city': c, 'province': p, 'is_capital': False})
    return results[:10]


def fetch_weather_data(city):
    api_key = settings.OPENWEATHER_API_KEY
    base_url = "https://api.openweathermap.org/data/2.5"
    try:
        cur_res = requests.get(
            f"{base_url}/weather",
            params={"q": f"{city},IR", "appid": api_key, "units": "metric", "lang": "fa"},
            timeout=10
        )
        fore_res = requests.get(
            f"{base_url}/forecast",
            params={"q": f"{city},IR", "appid": api_key, "units": "metric", "lang": "fa"},
            timeout=10
        )
        if cur_res.status_code == 200 and fore_res.status_code == 200:
            current = cur_res.json()
            forecast = fore_res.json()
            current['name'] = city
            return {'current': current, 'forecast': forecast.get('list', []), 'error': None}
        else:
            error_msg = "خطا در دریافت اطلاعات"
            if cur_res.status_code == 404 or fore_res.status_code == 404:
                error_msg = "شهر مورد نظر یافت نشد"
            return {'current': None, 'forecast': [], 'error': error_msg}
    except requests.RequestException:
        return {'current': None, 'forecast': [], 'error': "خطا در اتصال به سرور هواشناسی"}


def process_forecast_data(forecast_list):
    from datetime import datetime
    daily_raw = {}
    for item in forecast_list:
        dt = datetime.fromtimestamp(item['dt'])
        date_key = dt.strftime('%Y-%m-%d')
        if date_key not in daily_raw:
            daily_raw[date_key] = {
                'date_obj': dt,
                'temp_max': item['main']['temp_max'],
                'temp_min': item['main']['temp_min'],
                'icon': item['weather'][0]['icon'],
                'description': item['weather'][0]['description'],
            }
        else:
            daily_raw[date_key]['temp_max'] = max(daily_raw[date_key]['temp_max'], item['main']['temp_max'])
            daily_raw[date_key]['temp_min'] = min(daily_raw[date_key]['temp_min'], item['main']['temp_min'])

    daily = []
    for i, (key, data) in enumerate(sorted(daily_raw.items())):
        if i >= 5:
            break
        data['day_name'] = DAY_NAMES[data['date_obj'].weekday()]
        data['day_num'] = data['date_obj'].day
        data['month_num'] = data['date_obj'].month
        data['is_today'] = (i == 0)
        daily.append(data)

    hourly = []
    for i, item in enumerate(forecast_list[:8]):
        dt = datetime.fromtimestamp(item['dt'])
        hourly.append({
            'is_now': (i == 0),
            'hour': dt.hour,
            'temp': round(item['main']['temp']),
            'icon': item['weather'][0]['icon'],
        })

    return {'daily': daily, 'hourly': hourly}
