"""
WSGI config for iran_weather project.
"""

import os

from django.core.wsgi import get_wsgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'iran_weather.settings')

application = get_wsgi_application()
