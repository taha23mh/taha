from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Province, City
from .serializers import ProvinceSerializer
from .utils import fetch_weather


@api_view(["GET"])
def provinces_list(request):
    """GET /api/provinces/"""
    provinces = Province.objects.prefetch_related("cities").all()
    serializer = ProvinceSerializer(provinces, many=True)
    return Response(serializer.data)


@api_view(["GET"])
def city_weather(request):
    """GET /api/weather/?city=NAME"""
    city_name = request.query_params.get("city")
    if not city_name:
        return Response({"error": "city parameter is required"}, status=status.HTTP_400_BAD_REQUEST)
    try:
        data = fetch_weather(city_name, "weather")
        return Response(data)
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)


@api_view(["GET"])
def city_forecast(request):
    """GET /api/forecast/?city=NAME"""
    city_name = request.query_params.get("city")
    if not city_name:
        return Response({"error": "city parameter is required"}, status=status.HTTP_400_BAD_REQUEST)
    try:
        data = fetch_weather(city_name, "forecast")
        return Response(data)
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
