from django.urls import path
from .views import provinces_list, city_weather, city_forecast

urlpatterns = [
    path("provinces/", provinces_list, name="provinces-list"),
    path("weather/", city_weather, name="city-weather"),
    path("forecast/", city_forecast, name="city-forecast"),
]
