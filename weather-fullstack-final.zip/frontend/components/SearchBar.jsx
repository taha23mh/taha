"use client";
import { useState, useEffect, useRef } from "react";
import { normalizeFa } from "@/app/data";

export default function SearchBar({ provinces, onSelectCity }) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [activeIndex, setActiveIndex] = useState(-1);
  const containerRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setShowDropdown(false);
      setActiveIndex(-1);
      return;
    }
    const nq = normalizeFa(query.trim());
    const res = [];
    provinces.forEach((p) => {
      if (normalizeFa(p.name).includes(nq) || normalizeFa(p.capital).includes(nq))
        res.push({ city: p.capital, province: p, isCapital: true });
      p.cities?.forEach((c) => {
        if (normalizeFa(c.name).includes(nq) && c.name !== p.capital)
          res.push({ city: c.name, province: p, isCapital: false });
      });
    });
    setResults(res.slice(0, 10));
    setShowDropdown(true);
    setActiveIndex(-1);
  }, [query, provinces]);

  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleKeyDown = (e) => {
    if (!showDropdown) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((i) => (i + 1 < results.length ? i + 1 : 0));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => (i - 1 >= 0 ? i - 1 : results.length - 1));
    } else if (e.key === "Enter" && activeIndex >= 0) {
      e.preventDefault();
      const r = results[activeIndex];
      if (r) selectResult(r);
    } else if (e.key === "Escape") {
      setShowDropdown(false);
      inputRef.current?.blur();
    }
  };

  const selectResult = (r) => {
    setQuery("");
    setShowDropdown(false);
    setActiveIndex(-1);
    onSelectCity(r.city, r.province);
  };

  return (
    <section className="mb-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl sm:text-5xl font-bold mb-3 leading-tight">
          آب و هوای <span className="temp-gradient">ایران</span> را کشف کنید
        </h2>
        <p className="text-sm sm:text-base" style={{ color: "var(--text-muted)" }}>
          وضعیت آب و هوای لحظه‌ای و پیش‌بینی ۵ روزه شهرهای ایران
        </p>
      </div>
      <div ref={containerRef} className="relative max-w-2xl mx-auto">
        <i className="fa-solid fa-magnifying-glass absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"></i>
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={handleKeyDown}
          onFocus={() => query.trim() && setShowDropdown(true)}
          placeholder="نام شهر یا استان را تایپ کنید..."
          className="search-input w-full rounded-2xl py-4 pr-12 pl-10 text-sm sm:text-base"
          autoComplete="off"
        />
        {query && (
          <button
            onClick={() => { setQuery(""); setShowDropdown(false); inputRef.current?.focus(); }}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition"
          >
            <i className="fa-solid fa-xmark"></i>
          </button>
        )}
        {showDropdown && (
          <div
            className="absolute top-full mt-2 w-full rounded-2xl shadow-2xl overflow-hidden z-[100] max-h-80 overflow-y-auto scrollbar-hide"
            style={{ background: "var(--bg-mid)", border: "1px solid var(--glass-border)" }}
          >
            {results.length === 0 ? (
              <div className="p-4 text-center text-sm" style={{ color: "var(--text-muted)" }}>
                نتیجه‌ای یافت نشد
              </div>
            ) : (
              results.map((r, idx) => (
                <button
                  key={`${r.city}-${idx}`}
                  onClick={() => selectResult(r)}
                  className={`dropdown-item w-full text-right px-4 py-3 flex items-center justify-between border-b last:border-0 ${
                    idx === activeIndex ? "bg-amber-400/10" : ""
                  }`}
                  style={{ borderColor: "var(--glass-border)" }}
                >
                  <div>
                    <span className="text-sm font-medium block">{r.city}</span>
                    <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                      استان {r.province.name} {r.isCapital && " (مرکز)"}
                    </span>
                  </div>
                  <i className="fa-solid fa-chevron-left text-xs opacity-30"></i>
                </button>
              ))
            )}
          </div>
        )}
      </div>
    </section>
  );
}
