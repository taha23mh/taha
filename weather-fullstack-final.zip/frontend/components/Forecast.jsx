"use client";
import { toPersianNum, getWeatherType, dayNames } from "@/app/data";

export default function Forecast({ forecast, loading }) {
  if (loading && !forecast.length) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <i className="fa-solid fa-calendar-days text-amber-400"></i>
          پیش‌بینی ۵ روزه
        </h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
          {[1,2,3,4,5].map(i => <div key={i} className="h-40 w-full shimmer"></div>)}
        </div>
      </section>
    );
  }
  if (!forecast.length) return null;

  const daily = {};
  forecast.forEach((item) => {
    const date = new Date(item.dt * 1000);
    const dayKey = date.toLocaleDateString("fa-IR");
    if (!daily[dayKey]) {
      daily[dayKey] = { date, items: [], temps: [] };
    }
    daily[dayKey].items.push(item);
    daily[dayKey].temps.push(item.main.temp);
  });

  const days = Object.values(daily).slice(0, 5);

  return (
    <section className="mb-8">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <i className="fa-solid fa-calendar-days text-amber-400"></i>
        پیش‌بینی ۵ روزه
      </h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
        {days.map((day, idx) => {
          const maxTemp = Math.max(...day.temps);
          const minTemp = Math.min(...day.temps);
          const midItem = day.items[Math.floor(day.items.length / 2)];
          const wt = getWeatherType(midItem.weather?.[0]?.icon);
          const dayName = dayNames[day.date.getDay()];

          return (
            <div key={idx} className="forecast-card p-4 text-center">
              <p className="text-xs font-medium mb-3" style={{ color: "var(--text-muted)" }}>{dayName}</p>
              <div className="text-4xl mb-3" style={{ color: wt.color, filter: `drop-shadow(0 0 8px ${wt.color}30)` }}>
                <i className={`fa-solid ${wt.icon}`}></i>
              </div>
              <p className="text-sm font-medium mb-2">{wt.name}</p>
              <div className="flex items-center justify-center gap-2 text-sm">
                <span className="font-bold">{toPersianNum(Math.round(maxTemp))}°</span>
                <span style={{ color: "var(--text-muted)" }}>/</span>
                <span style={{ color: "var(--text-muted)" }}>{toPersianNum(Math.round(minTemp))}°</span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
