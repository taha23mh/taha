"use client";
import Link from "next/link";

export default function ProvincesList({ provinces, currentCity, onSelectCity }) {
  if (!provinces.length) {
    return (
      <div className="glass-card p-6 h-full">
        <h3 className="text-lg font-bold mb-4">استان‌ها</h3>
        <div className="space-y-2">
          {[1,2,3,4,5].map(i => <div key={i} className="h-10 w-full shimmer"></div>)}
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card p-6 h-full max-h-[400px] overflow-y-auto scrollbar-hide">
      <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
        <i className="fa-solid fa-list-ul text-amber-400"></i>
        استان‌ها
      </h3>
      <div className="space-y-2">
        {provinces.map((p) => (
          <button
            key={p.id}
            onClick={() => onSelectCity(p.capital, p)}
            className={`province-btn px-4 py-3 flex items-center justify-between ${
              currentCity === p.capital ? "active" : ""
            }`}
          >
            <div className="flex items-center gap-3">
              <i className={`fa-solid fa-city text-xs ${currentCity === p.capital ? "text-amber-400" : "text-slate-400"}`}></i>
              <div className="text-right">
                <p className="text-sm font-medium">{p.name}</p>
                <p className="text-xs opacity-60">{p.capital}</p>
              </div>
            </div>
            <Link
              href={`/city/${encodeURIComponent(p.capital)}`}
              onClick={(e) => e.stopPropagation()}
              className="text-xs px-2 py-1 rounded-lg bg-white/5 hover:bg-amber-400/20 hover:text-amber-400 transition"
            >
              <i className="fa-solid fa-arrow-left"></i>
            </Link>
          </button>
        ))}
      </div>
    </div>
  );
}
