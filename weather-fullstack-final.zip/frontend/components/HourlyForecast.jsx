"use client";
import { toPersianNum, getWeatherType } from "@/app/data";

export default function HourlyForecast({ forecast, loading }) {
  if (loading && !forecast.length) {
    return (
      <section className="mb-8">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <i className="fa-solid fa-clock text-amber-400"></i>
          پیش‌بینی ساعتی
        </h3>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {[1,2,3,4,5,6,7,8].map(i => <div key={i} className="h-32 w-24 flex-shrink-0 shimmer"></div>)}
        </div>
      </section>
    );
  }
  if (!forecast.length) return null;

  const next24 = forecast.slice(0, 8);

  return (
    <section className="mb-8">
      <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
        <i className="fa-solid fa-clock text-amber-400"></i>
        پیش‌بینی ساعتی
      </h3>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide">
        {next24.map((item, idx) => {
          const date = new Date(item.dt * 1000);
          const hour = date.getHours().toString().padStart(2, "0");
          const wt = getWeatherType(item.weather?.[0]?.icon);
          return (
            <div key={idx} className="hourly-card p-3 text-center flex-1 min-w-[90px]">
              <p className="text-xs mb-2" style={{ color: "var(--text-muted)" }}>{toPersianNum(hour)}:۰۰</p>
              <div className="text-2xl mb-2" style={{ color: wt.color }}>
                <i className={`fa-solid ${wt.icon}`}></i>
              </div>
              <p className="text-sm font-bold">{toPersianNum(Math.round(item.main?.temp))}°</p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
