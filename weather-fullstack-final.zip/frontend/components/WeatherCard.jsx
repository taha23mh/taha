"use client";
import { toPersianNum, getWeatherType } from "@/app/data";

export default function WeatherCard({ weather, province, loading }) {
  if (loading && !weather) {
    return (
      <div className="glass-card p-8 h-full flex flex-col items-center justify-center gap-4">
        <div className="w-16 h-16 rounded-full shimmer"></div>
        <div className="w-32 h-6 shimmer"></div>
        <div className="w-24 h-4 shimmer"></div>
      </div>
    );
  }
  if (!weather) {
    return (
      <div className="glass-card p-8 text-center h-full flex items-center justify-center" style={{ color: "var(--text-muted)" }}>
        اطلاعاتی موجود نیست
      </div>
    );
  }

  const wt = getWeatherType(weather.weather?.[0]?.icon);

  return (
    <div className="glass-card p-6 sm:p-8 h-full">
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <i className="fa-solid fa-location-dot text-amber-400"></i>
            <h3 className="text-2xl sm:text-3xl font-bold">{weather.name}</h3>
          </div>
          <p className="text-sm" style={{ color: "var(--text-muted)" }}>
            استان {province?.name || "نامشخص"}
          </p>
        </div>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium bg-amber-400/10 text-amber-400 border border-amber-400/20">
          <i className="fa-solid fa-circle text-[6px] animate-pulse"></i>
          <span>{weather.weather?.[0]?.description || "نامشخص"}</span>
        </div>
      </div>
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right">
          <div
            className="cloud-float text-7xl w-32 h-32 flex items-center justify-center"
            style={{ color: wt.color, filter: `drop-shadow(0 0 15px ${wt.color}40)` }}
          >
            <i className={`fa-solid ${wt.icon}`}></i>
          </div>
          <div>
            <div className="flex items-start justify-center sm:justify-start">
              <span className="text-7xl sm:text-8xl temp-gradient tracking-tighter">
                {toPersianNum(Math.round(weather.main?.temp))}
              </span>
              <span className="text-3xl text-amber-400 mt-2">°</span>
            </div>
            <p className="text-sm mt-2" style={{ color: "var(--text-muted)" }}>
              دمای محسوس: {toPersianNum(Math.round(weather.main?.feels_like))}°
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 w-full sm:w-auto sm:min-w-[200px]">
          <div className="info-card p-3">
            <div className="flex items-center gap-2 text-xs mb-1" style={{ color: "var(--text-muted)" }}>
              <i className="fa-solid fa-temperature-high text-rose-400"></i>
              <span>حداکثر</span>
            </div>
            <p className="text-lg font-bold">{toPersianNum(Math.round(weather.main?.temp_max))}°</p>
          </div>
          <div className="info-card p-3">
            <div className="flex items-center gap-2 text-xs mb-1" style={{ color: "var(--text-muted)" }}>
              <i className="fa-solid fa-temperature-low text-sky-400"></i>
              <span>حداقل</span>
            </div>
            <p className="text-lg font-bold">{toPersianNum(Math.round(weather.main?.temp_min))}°</p>
          </div>
        </div>
      </div>
      <p className="text-sm mt-6 leading-relaxed info-card p-4">
        وضعیت هوا: {weather.weather?.[0]?.description || "نامشخص"}. دمای فعلی{" "}
        {toPersianNum(Math.round(weather.main?.temp))} درجه سانتی‌گراد است.
      </p>
    </div>
  );
}
