import "./globals.css";

export const metadata = {
  title: "هواشناسی ایران",
  description: "پیش‌بینی دقیق آب و هوای شهرهای ایران",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fa" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@100;200;300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
        <link
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
          rel="stylesheet"
        />
      </head>
      <body className="bg-gradient-main min-h-screen text-white font-vazirmatn antialiased">
        {children}
      </body>
    </html>
  );
}
