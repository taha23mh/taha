"use client";
import { useState, useEffect } from "react";
import Header from "@/components/Header";
import SearchBar from "@/components/SearchBar";
import WeatherCard from "@/components/WeatherCard";
import QuickInfo from "@/components/QuickInfo";
import IranMap from "@/components/IranMap";
import ProvincesList from "@/components/ProvincesList";
import Forecast from "@/components/Forecast";
import HourlyForecast from "@/components/HourlyForecast";
import ExtraInfo from "@/components/ExtraInfo";
import { fetchCityWeather, fetchCityForecast, fetchProvinces } from "@/lib/api";

export default function Home() {
  const [city, setCity] = useState("تهران");
  const [province, setProvince] = useState(null);
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState("dark");
  const [provinces, setProvinces] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    const saved = localStorage.getItem("weather-theme");
    if (saved) setTheme(saved);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("weather-theme", theme);
  }, [theme]);

  useEffect(() => {
    fetchProvinces()
      .then((data) => {
        setProvinces(data);
        const tehran = data.find((p) => p.capital === "تهران");
        setProvince(tehran || data[0]);
      })
      .catch((err) => {
        console.error("Failed to fetch provinces:", err);
        setError("خطا در دریافت لیست استان‌ها");
      });
  }, []);

  useEffect(() => {
    if (!city) return;
    setLoading(true);
    setError(null);
    Promise.all([fetchCityWeather(city), fetchCityForecast(city)])
      .then(([w, f]) => {
        w.name = city;
        setWeather(w);
        setForecast(f.list || []);
      })
      .catch((err) => {
        console.error(err);
        setError(`خطا در دریافت اطلاعات ${city}`);
        setWeather(null);
        setForecast([]);
      })
      .finally(() => setLoading(false));
  }, [city]);

  const handleSelectCity = (newCity, newProvince) => {
    setCity(newCity);
    if (newProvince) setProvince(newProvince);
  };

  return (
    <div className="pb-10">
      <Header theme={theme} onToggleTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))} />
      <main className="max-w-7xl mx-auto px-4 py-6">
        {error && (
          <div className="mb-6 p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-center">
            {error}
          </div>
        )}
        <SearchBar provinces={provinces} onSelectCity={handleSelectCity} />
        <section className="mb-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <WeatherCard weather={weather} province={province} loading={loading} />
            </div>
            <QuickInfo weather={weather} loading={loading} />
          </div>
        </section>
        <section className="mb-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <IranMap provinces={provinces} currentCity={city} onSelectCity={handleSelectCity} />
          </div>
          <ProvincesList provinces={provinces} currentCity={city} onSelectCity={handleSelectCity} />
        </section>
        <Forecast forecast={forecast} loading={loading} />
        <HourlyForecast forecast={forecast} loading={loading} />
        <ExtraInfo weather={weather} loading={loading} />
      </main>
    </div>
  );
}
