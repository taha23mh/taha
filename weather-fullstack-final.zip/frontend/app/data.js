"use client";
export const weatherTypes = {
  "01d": { name: "آفتابی", icon: "fa-sun", color: "#f5b942" },
  "01n": { name: "آفتابی", icon: "fa-moon", color: "#f5b942" },
  "02d": { name: "نیمه ابری", icon: "fa-cloud-sun", color: "#9bb8d9" },
  "02n": { name: "نیمه ابری", icon: "fa-cloud", color: "#9bb8d9" },
  "03d": { name: "ابری", icon: "fa-cloud", color: "#8b92b8" },
  "03n": { name: "ابری", icon: "fa-cloud", color: "#8b92b8" },
  "04d": { name: "ابری", icon: "fa-cloud", color: "#8b92b8" },
  "04n": { name: "ابری", icon: "fa-cloud", color: "#8b92b8" },
  "09d": { name: "بارانی", icon: "fa-cloud-rain", color: "#4fc3f7" },
  "09n": { name: "بارانی", icon: "fa-cloud-rain", color: "#4fc3f7" },
  "10d": { name: "بارانی", icon: "fa-cloud-rain", color: "#4fc3f7" },
  "10n": { name: "بارانی", icon: "fa-cloud-moon-rain", color: "#4fc3f7" },
  "11d": { name: "رعد و برق", icon: "fa-cloud-bolt", color: "#9b6dff" },
  "11n": { name: "رعد و برق", icon: "fa-cloud-bolt", color: "#9b6dff" },
  "13d": { name: "برفی", icon: "fa-snowflake", color: "#e0f4ff" },
  "13n": { name: "برفی", icon: "fa-snowflake", color: "#e0f4ff" },
  "50d": { name: "مه‌آلود", icon: "fa-smog", color: "#b8bfd9" },
  "50n": { name: "مه‌آلود", icon: "fa-smog", color: "#b8bfd9" },
};

export const windDirections = ["شمال", "شمال شرق", "شرق", "جنوب شرق", "جنوب", "جنوب غرب", "غرب", "شمال غرب"];

// FIXED: getDay() returns 0=Saturday(شنبه) in Iran, so mapping is correct now
export const dayNames = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];

export const toPersianNum = (num) => {
  if (num === undefined || num === null) return "--";
  return num.toString().replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
};

export const normalizeFa = (text) =>
  text?.toString()
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/أ/g, "ا")
    .replace(/إ/g, "ا")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ی")
    .trim() || "";

export const getWeatherType = (iconCode) => weatherTypes[iconCode] || weatherTypes["01d"];

export const degToCompass = (deg) => {
  if (deg === undefined || deg === null) return "نامشخص";
  const val = Math.floor(deg / 45 + 0.5);
  return windDirections[val % 8];
};
