"use client";
import { useState, useEffect } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import { fetchProvinces } from "@/lib/api";

export default function ProvincesPage() {
  const [provinces, setProvinces] = useState([]);
  const [search, setSearch] = useState("");
  const [theme, setTheme] = useState("dark");

  useEffect(() => {
    const saved = localStorage.getItem("weather-theme");
    if (saved) setTheme(saved);
    fetchProvinces().then(setProvinces);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("weather-theme", theme);
  }, [theme]);

  const filtered = provinces.filter(
    (p) => p.name?.includes(search) || p.capital?.includes(search)
  );

  return (
    <div className="pb-10 min-h-screen bg-gradient-main">
      <Header theme={theme} onToggleTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))} />
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-6 text-sm" style={{ color: "var(--text-muted)" }}>
          <Link href="/" className="hover:text-amber-400 transition flex items-center gap-1">
            <i className="fa-solid fa-arrow-right"></i>
            بازگشت
          </Link>
        </div>
        <h1 className="text-3xl font-bold mb-6 flex items-center gap-2">
          <i className="fa-solid fa-map text-amber-400"></i>
          استان‌ها و شهرهای ایران
        </h1>
        <div className="relative max-w-xl mb-8">
          <i className="fa-solid fa-magnifying-glass absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="جستجوی استان یا شهر..."
            className="search-input w-full rounded-2xl py-3 pr-12 pl-4"
          />
          {search && (
            <button
              onClick={() => setSearch("")}
              className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition"
            >
              <i className="fa-solid fa-xmark"></i>
            </button>
          )}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((p) => (
            <div key={p.id} className="glass-card p-5 hover:border-amber-400/40 transition">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-lg">{p.name}</h3>
                <Link
                  href={`/city/${encodeURIComponent(p.capital)}`}
                  className="text-xs bg-amber-400/10 text-amber-400 px-3 py-1 rounded-full hover:bg-amber-400 hover:text-black transition"
                >
                  مشاهده آب و هوا
                </Link>
              </div>
              <p className="text-sm mb-3" style={{ color: "var(--text-muted)" }}>
                مرکز استان: <span style={{ color: "var(--text-primary)" }}>{p.capital}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {p.cities?.map((c) => (
                  <Link
                    key={c.id}
                    href={`/city/${encodeURIComponent(c.name)}`}
                    className="text-xs px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 transition"
                    style={{ border: "1px solid var(--glass-border)" }}
                  >
                    {c.name}
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}
