"use client";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import Link from "next/link";
import Header from "@/components/Header";
import WeatherCard from "@/components/WeatherCard";
import QuickInfo from "@/components/QuickInfo";
import Forecast from "@/components/Forecast";
import HourlyForecast from "@/components/HourlyForecast";
import ExtraInfo from "@/components/ExtraInfo";
import { fetchCityWeather, fetchCityForecast, fetchProvinces } from "@/lib/api";

export default function CityPage() {
  const params = useParams();
  const cityName = decodeURIComponent(params.name);
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [province, setProvince] = useState(null);
  const [loading, setLoading] = useState(true);
  const [theme, setTheme] = useState("dark");
  const [error, setError] = useState(null);

  useEffect(() => {
    const saved = localStorage.getItem("weather-theme");
    if (saved) setTheme(saved);
  }, []);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("weather-theme", theme);
  }, [theme]);

  useEffect(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      fetchCityWeather(cityName),
      fetchCityForecast(cityName),
      fetchProvinces(),
    ])
      .then(([w, f, provinces]) => {
        w.name = cityName;
        setWeather(w);
        setForecast(f.list || []);
        const p = provinces.find(
          (pro) => pro.capital === cityName || pro.cities?.some((c) => c.name === cityName)
        );
        setProvince(p);
      })
      .catch((err) => {
        console.error(err);
        setError("خطا در دریافت اطلاعات");
      })
      .finally(() => setLoading(false));
  }, [cityName]);

  return (
    <div className="pb-10 min-h-screen bg-gradient-main">
      <Header theme={theme} onToggleTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))} />
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-6 text-sm" style={{ color: "var(--text-muted)" }}>
          <Link href="/" className="hover:text-amber-400 transition flex items-center gap-1">
            <i className="fa-solid fa-arrow-right"></i>
            بازگشت به داشبورد
          </Link>
        </div>
        {error && (
          <div className="mb-6 p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-center">
            {error}
          </div>
        )}
        <h1 className="text-3xl font-bold mb-6 flex items-center gap-3">
          <i className="fa-solid fa-city text-amber-400"></i>
          آب و هوای {cityName}
        </h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <WeatherCard weather={weather} province={province} loading={loading} />
          </div>
          <QuickInfo weather={weather} loading={loading} />
        </div>
        <Forecast forecast={forecast} loading={loading} />
        <HourlyForecast forecast={forecast} loading={loading} />
        <ExtraInfo weather={weather} loading={loading} />
      </main>
    </div>
  );
}
