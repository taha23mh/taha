"use client";
import { toPersianNum, getWeatherType, dayNames } from "@/app/data";

function groupByDay(list) {
  const daily = {};
  list.forEach((item) => {
    const date = new Date(item.dt * 1000);
    const key = date.toDateString();
    if (!daily[key]) {
      daily[key] = {
        date,
        tempMax: item.main.temp_max,
        tempMin: item.main.temp_min,
        icon: item.weather[0].icon,
        description: item.weather[0].description,
      };
    } else {
      daily[key].tempMax = Math.max(daily[key].tempMax, item.main.temp_max);
      daily[key].tempMin = Math.min(daily[key].tempMin, item.main.temp_min);
    }
  });
  return Object.values(daily).slice(0, 5);
}

export default function Forecast({ forecast, loading }) {
  const days = forecast.length ? groupByDay(forecast) : [];

  return (
    <section className="mb-8">
      <div className="glass-card p-6">
        <h4 className="text-base font-semibold flex items-center gap-2 mb-5">
          <i className="fa-solid fa-calendar-week text-amber-400"></i> پیش‌بینی ۵ روز آینده
        </h4>

        {loading && !forecast.length ? (
          <p className="text-center text-amber-400 py-6">در حال بارگذاری...</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {days.map((day, index) => {
              const wt = getWeatherType(day.icon);
              return (
                <div
                  key={index}
                  className={`forecast-card p-4 text-center ${index === 0 ? "border-amber-400/40" : ""}`}
                >
                  <p className="text-xs mb-1" style={{ color: "var(--text-muted)" }}>
                    {index === 0 ? "امروز" : dayNames[day.date.getDay()]}
                  </p>
                  <p className="text-[10px] mb-3" style={{ color: "var(--text-muted)" }}>
                    {day.date.getDate()}/{day.date.getMonth() + 1}
                  </p>
                  <div
                    className="text-3xl mb-3"
                    style={{ color: wt.color, filter: `drop-shadow(0 0 8px ${wt.color}40)` }}
                  >
                    <i className={`fa-solid ${wt.icon}`}></i>
                  </div>
                  <div className="flex items-center justify-center gap-2 text-sm">
                    <span className="font-bold">{toPersianNum(Math.round(day.tempMax))}°</span>
                    <span style={{ color: "var(--text-muted)" }}>
                      {toPersianNum(Math.round(day.tempMin))}°
                    </span>
                  </div>
                  <p className="text-[10px] mt-2" style={{ color: "var(--text-muted)" }}>
                    {day.description}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
