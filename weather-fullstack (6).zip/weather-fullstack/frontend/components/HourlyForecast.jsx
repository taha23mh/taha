"use client";
import { useRef, useState } from "react";
import { toPersianNum, getWeatherType } from "@/app/data";

export default function HourlyForecast({ forecast, loading }) {
  const sliderRef = useRef(null);
  const [isDown, setIsDown] = useState(false);
  const dragRef = useRef({ startX: 0, scrollLeft: 0 });

  const onMouseDown = (e) => {
    setIsDown(true);
    if (sliderRef.current) sliderRef.current.classList.add("drag-active");
    dragRef.current = {
      startX: e.pageX - sliderRef.current.offsetLeft,
      scrollLeft: sliderRef.current.scrollLeft,
    };
  };
  const stopDrag = () => {
    setIsDown(false);
    if (sliderRef.current) sliderRef.current.classList.remove("drag-active");
  };
  const onMouseMove = (e) => {
    if (!isDown || !sliderRef.current) return;
    e.preventDefault();
    const x = e.pageX - sliderRef.current.offsetLeft;
    const walk = (x - dragRef.current.startX) * 2;
    sliderRef.current.scrollLeft = dragRef.current.scrollLeft - walk;
  };

  const hourly = forecast.slice(0, 8);

  return (
    <section className="mb-8">
      <div className="glass-card p-6">
        <h4 className="text-base font-semibold flex items-center gap-2 mb-5">
          <i className="fa-solid fa-clock text-amber-400"></i> پیش‌بینی ساعات آینده
        </h4>

        {loading && !forecast.length ? (
          <p className="text-center text-amber-400 py-6">در حال بارگذاری...</p>
        ) : (
          <div
            ref={sliderRef}
            className="overflow-x-auto pb-3"
            onMouseDown={onMouseDown}
            onMouseLeave={stopDrag}
            onMouseUp={stopDrag}
            onMouseMove={onMouseMove}
          >
            <div className="flex gap-3" style={{ minWidth: "max-content" }}>
              {hourly.map((hour, index) => {
                const wt = getWeatherType(hour.weather[0].icon);
                const date = new Date(hour.dt * 1000);
                return (
                  <div
                    key={index}
                    className={`hourly-card p-3 text-center ${index === 0 ? "border-amber-400/40" : ""}`}
                  >
                    <p
                      className={`text-xs mb-2 ${index === 0 ? "text-amber-400 font-bold" : ""}`}
                      style={index !== 0 ? { color: "var(--text-muted)" } : {}}
                    >
                      {index === 0
                        ? "اکنون"
                        : `${toPersianNum(date.getHours().toString().padStart(2, "0"))}:۰۰`}
                    </p>
                    <div className="text-2xl mb-2" style={{ color: wt.color }}>
                      <i className={`fa-solid ${wt.icon}`}></i>
                    </div>
                    <p className="text-sm font-bold">{toPersianNum(Math.round(hour.main.temp))}°</p>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
