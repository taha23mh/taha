"use client";
export default function IranMap({ provinces, currentCity, onSelectCity }) {
  return (
    <div className="lg:col-span-3 glass-card p-3">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h4 className="text-base font-semibold flex items-center gap-2">
          <i className="fa-solid fa-map-location-dot text-amber-400"></i> نقشه تعاملی ایران
        </h4>
        <p className="text-xs" style={{ color: "var(--text-muted)" }}>
          برای انتخاب شهر روی نقاط کلیک کنید
        </p>
      </div>

      <div className="relative rounded-2xl overflow-hidden">
        <img src="/map.jpg" alt="نقشه ایران" className="w-full h-auto select-none pointer-events-none" />

        {provinces.map((p) => (
          <div
            key={p.id}
            className={`map-group ${currentCity === p.capital ? "active" : ""}`}
            style={{ left: `${p.x}%`, top: `${p.y}%` }}
            onClick={() => onSelectCity(p.capital, p)}
          >
            <div className="relative">
              {currentCity === p.capital && <div className="pulse-ring"></div>}
              <div className={`map-dot ${currentCity === p.capital ? "active" : ""}`}></div>
              <div className="map-label">{p.capital}</div>
            </div>
          </div>
        ))}

        <div
          className="absolute bottom-4 left-4 backdrop-blur-md rounded-xl p-2 text-xs border"
          style={{ background: "rgba(0,0,0,0.4)", borderColor: "var(--glass-border)" }}
        >
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-sky-400"></div>
            <span style={{ color: "var(--text-soft)" }}>مرکز استان‌ها</span>
          </div>
        </div>
      </div>
    </div>
  );
}
