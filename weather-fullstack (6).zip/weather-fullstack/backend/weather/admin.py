from django.contrib import admin
from .models import Province, City, WeatherCache


@admin.register(Province)
class ProvinceAdmin(admin.ModelAdmin):
    list_display = ["name", "capital", "lat", "lon"]
    search_fields = ["name", "capital"]


@admin.register(City)
class CityAdmin(admin.ModelAdmin):
    list_display = ["name", "province", "is_capital"]
    list_filter = ["is_capital"]
    search_fields = ["name"]


@admin.register(WeatherCache)
class WeatherCacheAdmin(admin.ModelAdmin):
    list_display = ["city", "data_type", "updated_at"]
    list_filter = ["data_type"]
