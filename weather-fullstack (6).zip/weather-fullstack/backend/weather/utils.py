import requests
from django.conf import settings
from django.utils import timezone
from .models import WeatherCache, City

API_KEY = settings.OPENWEATHER_API_KEY
BASE_URL = "https://api.openweathermap.org/data/2.5"


def fetch_weather(city_name, data_type="weather"):
    cache_type = "current" if data_type == "weather" else "forecast"
    try:
        city = City.objects.get(name=city_name)
        cache = WeatherCache.objects.filter(city=city, data_type=cache_type).first()
        if cache and (timezone.now() - cache.updated_at).seconds < 600:
            return cache.data
    except City.DoesNotExist:
        pass

    url = f"{BASE_URL}/{data_type}?q={city_name},IR&appid={API_KEY}&units=metric&lang=fa"
    res = requests.get(url, timeout=10)
    res.raise_for_status()
    data = res.json()

    try:
        city = City.objects.get(name=city_name)
        WeatherCache.objects.update_or_create(
            city=city, data_type=cache_type, defaults={"data": data}
        )
    except City.DoesNotExist:
        pass

    return data
