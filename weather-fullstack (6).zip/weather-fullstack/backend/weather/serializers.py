from rest_framework import serializers
from .models import Province, City


class CitySerializer(serializers.ModelSerializer):
    class Meta:
        model = City
        fields = ["id", "name", "lat", "lon", "is_capital"]


class ProvinceSerializer(serializers.ModelSerializer):
    cities = CitySerializer(many=True, read_only=True)

    class Meta:
        model = Province
        fields = ["id", "name", "capital", "lat", "lon", "x", "y", "cities"]
