from django.db import models


class Province(models.Model):
    name = models.CharField(max_length=100)
    capital = models.CharField(max_length=100)
    lat = models.FloatField()
    lon = models.FloatField()
    x = models.IntegerField(default=0)
    y = models.IntegerField(default=0)

    def __str__(self):
        return self.name


class City(models.Model):
    province = models.ForeignKey(Province, on_delete=models.CASCADE, related_name="cities")
    name = models.CharField(max_length=100)
    lat = models.FloatField(null=True, blank=True)
    lon = models.FloatField(null=True, blank=True)
    is_capital = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class WeatherCache(models.Model):
    DATA_TYPES = [
        ("current", "Current"),
        ("forecast", "Forecast"),
    ]
    city = models.ForeignKey(City, on_delete=models.CASCADE)
    data_type = models.CharField(max_length=20, choices=DATA_TYPES)
    data = models.JSONField()
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ["city", "data_type"]
