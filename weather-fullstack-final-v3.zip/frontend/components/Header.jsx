"use client";
import { useState, useEffect } from "react";
import { toPersianNum } from "@/app/data";
import Link from "next/link";

export default function Header({ theme, onToggleTheme }) {
  const [time, setTime] = useState("--:--:--");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const update = () => {
      const now = new Date();
      const h = now.getHours().toString().padStart(2, "0");
      const m = now.getMinutes().toString().padStart(2, "0");
      const s = now.getSeconds().toString().padStart(2, "0");
      setTime(`${h}:${m}:${s}`);
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  if (!mounted) return null;

  return (
    <header
      className="sticky top-0 z-50 backdrop-blur-xl border-b transition-colors duration-300"
      style={{
        background: theme === "dark" ? "rgba(10, 17, 40, 0.7)" : "rgba(255, 255, 255, 0.85)",
        borderColor: "var(--glass-border)",
      }}
    >
      <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-3 sm:py-4 flex items-center justify-between gap-3">
        <Link href="/" className="flex items-center gap-2 sm:gap-3 group">
          <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-xl sm:rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-500/30 group-hover:shadow-amber-500/50 transition">
            <i className="fa-solid fa-cloud-sun text-white text-base sm:text-xl"></i>
          </div>
          <div>
            <h1 className="text-base sm:text-lg md:text-xl font-bold leading-tight">هواشناسی ایران</h1>
            <p className="text-[10px] sm:text-xs hidden sm:block" style={{ color: "var(--text-muted)" }}>
              پیش‌بینی دقیق آب و هوای شهرهای ایران
            </p>
          </div>
        </Link>
        <div className="flex items-center gap-2 sm:gap-3">
          <div
            className="hidden md:flex items-center gap-2 text-xs px-3 py-2 rounded-xl font-mono"
            style={{
              background: "var(--input-bg)",
              border: "1px solid var(--glass-border)",
              color: "var(--text-muted)",
            }}
          >
            <i className="fa-regular fa-clock"></i>
            <span dir="ltr">{toPersianNum(time)}</span>
          </div>
          <button
            onClick={onToggleTheme}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center transition hover:scale-105 active:scale-95"
            style={{ background: "var(--input-bg)", border: "1px solid var(--glass-border)" }}
            aria-label="Toggle theme"
          >
            <i className={`fa-solid ${theme === "dark" ? "fa-moon" : "fa-sun"} text-amber-400 text-base sm:text-lg`}></i>
          </button>
        </div>
      </div>
    </header>
  );
}
