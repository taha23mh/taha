"use client";
import Link from "next/link";

export default function ProvincesList({ provinces, currentCity, onSelectCity }) {
  if (!provinces.length) {
    return (
      <div className="glass-card p-4 sm:p-6 h-full">
        <h3 className="text-sm sm:text-lg font-bold mb-3 sm:mb-4">استان‌ها</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {[1,2,3,4,5].map(i => <div key={i} className="h-9 sm:h-10 w-full shimmer"></div>)}
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card p-4 sm:p-6 h-full max-h-[350px] sm:max-h-[400px] overflow-y-auto scrollbar-hide">
      <h3 className="text-sm sm:text-lg font-bold mb-3 sm:mb-4 flex items-center gap-2">
        <i className="fa-solid fa-list-ul text-amber-400"></i>
        استان‌ها
      </h3>
      {/* FIXED: 2 columns on md+, 1 column on mobile */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {provinces.map((p) => (
          <button
            key={p.id}
            onClick={() => onSelectCity(p.capital, p)}
            className={`province-btn px-3 sm:px-4 py-2.5 sm:py-3 flex items-center justify-between ${
              currentCity === p.capital ? "active" : ""
            }`}
          >
            <div className="flex items-center gap-2 sm:gap-3 min-w-0">
              <i className={`fa-solid fa-city text-[10px] sm:text-xs flex-shrink-0 ${currentCity === p.capital ? "text-amber-400" : "text-slate-400"}`}></i>
              <div className="text-right min-w-0">
                <p className="text-xs sm:text-sm font-medium truncate">{p.name}</p>
                <p className="text-[10px] sm:text-xs opacity-60 truncate">{p.capital}</p>
              </div>
            </div>
            <Link
              href={`/city/${encodeURIComponent(p.capital)}`}
              onClick={(e) => e.stopPropagation()}
              className="text-[10px] sm:text-xs px-1.5 sm:px-2 py-1 rounded-lg bg-white/5 hover:bg-amber-400/20 hover:text-amber-400 transition flex-shrink-0 ml-1"
            >
              <i className="fa-solid fa-arrow-left"></i>
            </Link>
          </button>
        ))}
      </div>
    </div>
  );
}
