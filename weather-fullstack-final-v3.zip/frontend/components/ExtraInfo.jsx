"use client";
import { toPersianNum } from "@/app/data";

export default function ExtraInfo({ weather, loading }) {
  if (loading && !weather) {
    return (
      <section className="mb-6 sm:mb-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-24 sm:h-28 w-full shimmer"></div>)}
        </div>
      </section>
    );
  }
  if (!weather) return null;

  const sunrise = weather.sys?.sunrise ? new Date(weather.sys.sunrise * 1000) : null;
  const sunset = weather.sys?.sunset ? new Date(weather.sys.sunset * 1000) : null;

  const formatTime = (date) => {
    if (!date) return "--:--";
    const h = date.getHours().toString().padStart(2, "0");
    const m = date.getMinutes().toString().padStart(2, "0");
    return `${toPersianNum(h)}:${toPersianNum(m)}`;
  };

  return (
    <section className="mb-6 sm:mb-8 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
      <div className="info-card glass-card p-4 sm:p-5">
        <div className="flex items-center justify-between mb-2 sm:mb-3">
          <span className="text-[10px] sm:text-xs" style={{ color: "var(--text-muted)" }}>طلوع آفتاب</span>
          <i className="fa-solid fa-sun text-amber-400 text-lg sm:text-xl"></i>
        </div>
        <p className="text-lg sm:text-xl md:text-2xl font-bold">{formatTime(sunrise)}</p>
      </div>
      <div className="info-card glass-card p-4 sm:p-5">
        <div className="flex items-center justify-between mb-2 sm:mb-3">
          <span className="text-[10px] sm:text-xs" style={{ color: "var(--text-muted)" }}>غروب آفتاب</span>
          <i className="fa-solid fa-moon text-purple-400 text-lg sm:text-xl"></i>
        </div>
        <p className="text-lg sm:text-xl md:text-2xl font-bold">{formatTime(sunset)}</p>
      </div>
      <div className="info-card glass-card p-4 sm:p-5">
        <div className="flex items-center justify-between mb-2 sm:mb-3">
          <span className="text-[10px] sm:text-xs" style={{ color: "var(--text-muted)" }}>وضعیت هوا</span>
          <i className="fa-solid fa-cloud-sun text-sky-400 text-lg sm:text-xl"></i>
        </div>
        <p className="text-xs sm:text-sm font-bold line-clamp-1">{weather.weather?.[0]?.description || "نامشخص"}</p>
      </div>
      <div className="info-card glass-card p-4 sm:p-5">
        <div className="flex items-center justify-between mb-2 sm:mb-3">
          <span className="text-[10px] sm:text-xs" style={{ color: "var(--text-muted)" }}>مختصات</span>
          <i className="fa-solid fa-location-crosshairs text-rose-400 text-lg sm:text-xl"></i>
        </div>
        <p className="text-xs sm:text-sm font-bold">{toPersianNum(weather.coord?.lat)} / {toPersianNum(weather.coord?.lon)}</p>
      </div>
    </section>
  );
}
