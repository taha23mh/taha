"use client";
import { toPersianNum, getWeatherType } from "@/app/data";

export default function WeatherCard({ weather, province, loading }) {
  if (loading && !weather) {
    return (
      <div className="glass-card p-5 sm:p-8 h-full flex flex-col items-center justify-center gap-4">
        <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full shimmer"></div>
        <div className="w-28 sm:w-32 h-5 sm:h-6 shimmer"></div>
        <div className="w-20 sm:w-24 h-3 sm:h-4 shimmer"></div>
      </div>
    );
  }
  if (!weather) {
    return (
      <div className="glass-card p-5 sm:p-8 text-center h-full flex items-center justify-center text-sm" style={{ color: "var(--text-muted)" }}>
        اطلاعاتی موجود نیست
      </div>
    );
  }

  const wt = getWeatherType(weather.weather?.[0]?.icon);

  return (
    <div className="glass-card p-4 sm:p-6 md:p-8 h-full">
      <div className="flex items-start justify-between mb-4 sm:mb-6 flex-wrap gap-2 sm:gap-4">
        <div>
          <div className="flex items-center gap-1.5 sm:gap-2 mb-1 sm:mb-2">
            <i className="fa-solid fa-location-dot text-amber-400 text-sm sm:text-base"></i>
            <h3 className="text-xl sm:text-2xl md:text-3xl font-bold">{weather.name}</h3>
          </div>
          <p className="text-xs sm:text-sm" style={{ color: "var(--text-muted)" }}>
            استان {province?.name || "نامشخص"}
          </p>
        </div>
        <div className="inline-flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 sm:py-1.5 rounded-full text-[10px] sm:text-xs font-medium bg-amber-400/10 text-amber-400 border border-amber-400/20">
          <i className="fa-solid fa-circle text-[5px] sm:text-[6px] animate-pulse"></i>
          <span>{weather.weather?.[0]?.description || "نامشخص"}</span>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 sm:gap-6">
        <div className="flex flex-row sm:flex-row items-center gap-3 sm:gap-4 text-center sm:text-right">
          <div
            className="cloud-float text-5xl sm:text-6xl md:text-7xl w-20 h-20 sm:w-28 sm:h-28 md:w-32 md:h-32 flex items-center justify-center"
            style={{ color: wt.color, filter: `drop-shadow(0 0 15px ${wt.color}40)` }}
          >
            <i className={`fa-solid ${wt.icon}`}></i>
          </div>
          <div>
            <div className="flex items-start justify-center sm:justify-start">
              <span className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl temp-gradient tracking-tighter">
                {toPersianNum(Math.round(weather.main?.temp))}
              </span>
              <span className="text-2xl sm:text-3xl text-amber-400 mt-1 sm:mt-2">°</span>
            </div>
            <p className="text-xs sm:text-sm mt-1 sm:mt-2" style={{ color: "var(--text-muted)" }}>
              دمای محسوس: {toPersianNum(Math.round(weather.main?.feels_like))}°
            </p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:gap-3 w-full sm:w-auto sm:min-w-[160px] md:min-w-[200px]">
          <div className="info-card p-2.5 sm:p-3">
            <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs mb-1" style={{ color: "var(--text-muted)" }}>
              <i className="fa-solid fa-temperature-high text-rose-400"></i>
              <span>حداکثر</span>
            </div>
            <p className="text-base sm:text-lg font-bold">{toPersianNum(Math.round(weather.main?.temp_max))}°</p>
          </div>
          <div className="info-card p-2.5 sm:p-3">
            <div className="flex items-center gap-1.5 sm:gap-2 text-[10px] sm:text-xs mb-1" style={{ color: "var(--text-muted)" }}>
              <i className="fa-solid fa-temperature-low text-sky-400"></i>
              <span>حداقل</span>
            </div>
            <p className="text-base sm:text-lg font-bold">{toPersianNum(Math.round(weather.main?.temp_min))}°</p>
          </div>
        </div>
      </div>

      <p className="text-xs sm:text-sm mt-4 sm:mt-6 leading-relaxed info-card p-3 sm:p-4">
        وضعیت هوا: {weather.weather?.[0]?.description || "نامشخص"}. دمای فعلی{" "}
        {toPersianNum(Math.round(weather.main?.temp))} درجه سانتی‌گراد است.
      </p>
    </div>
  );
}
