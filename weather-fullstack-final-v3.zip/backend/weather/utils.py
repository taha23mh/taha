import requests
from django.conf import settings
from django.utils import timezone
from .models import WeatherCache, City

API_KEY = settings.OPENWEATHER_API_KEY
BASE_URL = "https://api.openweathermap.org/data/2.5"


def fetch_weather(city_name, data_type="weather"):
    if not API_KEY or API_KEY == "YOUR_API_KEY_HERE":
        raise Exception("کلید API OpenWeatherMap تنظیم نشده. لطفاً فایل backend/.env را ویرایش کنید.")

    cache_type = "current" if data_type == "weather" else "forecast"

    # Try cache first
    try:
        city = City.objects.filter(name=city_name).first()
        if city:
            cache = WeatherCache.objects.filter(city=city, data_type=cache_type).first()
            if cache and (timezone.now() - cache.updated_at).seconds < 600:
                return cache.data
    except Exception:
        pass

    # Fetch from OpenWeatherMap
    url = f"{BASE_URL}/{data_type}?q={city_name},IR&appid={API_KEY}&units=metric&lang=fa"
    try:
        res = requests.get(url, timeout=10)
        res.raise_for_status()
        data = res.json()
    except requests.exceptions.HTTPError:
        if res.status_code == 401:
            raise Exception("کلید API نامعتبر است. لطفاً کلید صحیح را در backend/.env وارد کنید.")
        elif res.status_code == 404:
            raise Exception(f"شهر '{city_name}' در پایگاه داده یافت نشد.")
        else:
            raise Exception(f"خطای سرور آب‌وهوا: {res.status_code}")
    except requests.exceptions.RequestException:
        raise Exception("اتصال به اینترنت برای دریافت اطلاعات آب‌وهوا برقرار نشد.")

    # Save to cache
    try:
        city = City.objects.filter(name=city_name).first()
        if city:
            WeatherCache.objects.update_or_create(
                city=city, data_type=cache_type, defaults={"data": data}
            )
    except Exception:
        pass

    return data
