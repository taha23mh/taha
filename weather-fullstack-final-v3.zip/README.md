# 🌤 هواشناسی ایران

اپلیکیشن وب پیش‌بینی آب و هوای شهرهای ایران با رابط کاربری مدرن و زیبا. این پروژه شامل بک‌اند Django و فرانت‌اند Next.js است و از API OpenWeatherMap برای دریافت اطلاعات لحظه‌ای و پیش‌بینی آب و هوا استفاده می‌کند.

---

## ✨ ویژگی‌ها

- 🌡 **وضعیت لحظه‌ای** — دما، رطوبت، سرعت باد، فشار هوا و...
- 📅 **پیش‌بینی ۵ روزه** — آب و هوای آینده با نمودار و آیکون
- ⏰ **پیش‌بینی ساعتی** — ۲۴ ساعت آینده به تفکیک ساعت
- 🗺 **نقشه تعاملی ایران** — کلیک روی شهرها برای مشاهده آب و هوا
- 🔍 **جستجوی هوشمند** — جستجوی شهر و استان با پیشنهادات لحظه‌ای
- 🌙 **تم دارک/لایت** — قابلیت تغییر تم با یک کلیک
- 📱 **ریسپانسیو** — نمایش مناسب روی موبایل، تبلت و دسکتاپ
- 🏛 **۳۱ استان ایران** — پوشش کامل استان‌ها و شهرهای مهم

---

## 🛠 تکنولوژی‌ها

### بک‌اند
- Python 3.10+
- Django 5.0
- Django REST Framework
- SQLite (پیش‌فرض)
- Requests

### فرانت‌اند
- Next.js 14
- React 18
- Tailwind CSS 3
- Font Awesome 6
- Google Fonts (Vazirmatn)

---

## 📋 پیش‌نیازها

قبل از نصب، این ابزارها را روی سیستم خود نصب کنید:

- [Python](https://www.python.org/downloads/) نسخه ۳.۱۰ یا بالاتر
- [Node.js](https://nodejs.org/) نسخه ۱۸ یا بالاتر
- [npm](https://www.npmjs.com/) (همراه Node.js نصب می‌شود)

---

## 🚀 نصب و راه‌اندازی

### ۱. استخراج فایل ZIP

```bash
unzip weather-fullstack-final-v3.zip
cd weather-fullstack-final-v3
```

---

### ۲. راه‌اندازی بک‌اند

```bash
cd backend

# ساخت محیط مجازی
python -m venv venv

# فعال‌سازی محیط مجازی (ویندوز)
venv\Scripts\activate

# فعال‌سازی محیط مجازی (لینوکس/مک)
source venv/bin/activate

# نصب وابستگی‌ها
pip install -r requirements.txt

# اجرای migrations
python manage.py migrate

# پر کردن دیتابیس با استان‌ها و شهرها
python manage.py seed_provinces

# اجرای سرور
python manage.py runserver
```

سرور بک‌اند روی `http://localhost:8000` اجرا می‌شود.

---

### ۳. تنظیم کلید API (مهم!)

برای دریافت اطلاعات آب و هوا، باید کلید API رایگان از [OpenWeatherMap](https://openweathermap.org/api) دریافت کنید.

سپس فایل `backend/.env` را ویرایش کنید:

```env
OPENWEATHER_API_KEY=کلید-API-شما
```

> ⚠️ بدون کلید API، بخش آب و هوا کار نخواهد کرد و پیام خطا نمایش داده می‌شود.

---

### ۴. راه‌اندازی فرانت‌اند

ترمینال جدید باز کنید:

```bash
cd frontend

# نصب وابستگی‌ها
npm install

# اجرای سرور توسعه
npm run dev
```

فرانت‌اند روی `http://localhost:3000` اجرا می‌شود.

---

## 📁 ساختار پروژه

```
weather-fullstack-final-v3/
├── backend/                 # بک‌اند Django
│   ├── core/               # تنظیمات اصلی پروژه
│   ├── weather/            # اپلیکیشن هواشناسی
│   │   ├── models.py       # مدل‌های Province, City, WeatherCache
│   │   ├── views.py        # API endpoints
│   │   ├── urls.py         # مسیرهای API
│   │   ├── utils.py        # اتصال به OpenWeatherMap
│   │   └── management/     # دستورات مدیریتی (seed)
│   ├── templates/          # قالب HTML
│   ├── manage.py           # فایل مدیریت Django
│   ├── requirements.txt    # وابستگی‌های Python
│   └── .env                # متغیرهای محیطی
│
└── frontend/               # فرانت‌اند Next.js
    ├── app/                # صفحات اپلیکیشن
    │   ├── page.js         # صفحه اصلی
    │   ├── layout.js       # لایه اصلی
    │   ├── globals.css     # استایل‌های سراسری
    │   ├── data.js         # داده‌های ثابت (آیکون‌ها، روزها)
    │   ├── city/[name]/    # صفحه جزئیات شهر
    │   ├── forecast/       # صفحه پیش‌بینی
    │   └── provinces/      # صفحه لیست استان‌ها
    ├── components/         # کامپوننت‌های React
    │   ├── Header.jsx
    │   ├── SearchBar.jsx
    │   ├── WeatherCard.jsx
    │   ├── QuickInfo.jsx
    │   ├── Forecast.jsx
    │   ├── HourlyForecast.jsx
    │   ├── IranMap.jsx
    │   └── ProvincesList.jsx
    ├── lib/api.js          # توابع API
    ├── public/             # فایل‌های استاتیک
    ├── package.json
    ├── tailwind.config.js
    └── postcss.config.js
```

---

## 🔗 API Endpoints

| مسیر | توضیحات |
|------|---------|
| `GET /api/provinces/` | لیست استان‌ها و شهرها |
| `GET /api/weather/?city=NAME` | آب و هوای لحظه‌ای شهر |
| `GET /api/forecast/?city=NAME` | پیش‌بینی ۵ روزه شهر |

---

## 🎨 شخصی‌سازی

### تغییر رنگ‌ها در لایت مود

فایل `frontend/app/globals.css` را باز کنید و این بخش را ویرایش کنید:

```css
[data-theme="light"] {
  --text-primary: #1a1a2e;    /* رنگ متن اصلی */
  --text-muted: #4a4a5a;      /* رنگ متن فرعی */
  --bg-deep: #fff1e6;          /* رنگ پس‌زمینه */
}
```

### تغییر ارتفاع لیست استان‌ها

فایل `frontend/components/ProvincesList.jsx`:

```jsx
max-h-[400px]   /* ارتفاع فعلی */
max-h-[500px]   /* بلندتر */
max-h-[300px]   /* کوتاه‌تر */
```

### تغییر تعداد ستون‌های لیست استان‌ها

فایل `frontend/components/ProvincesList.jsx`:

```jsx
<div className="grid grid-cols-1 md:grid-cols-2 gap-2">
```

- `grid-cols-1` = یک ستون (موبایل)
- `md:grid-cols-2` = دو ستون (دسکتاپ)

---

## 🖼 اضافه کردن عکس نقشه ایران

برای نمایش نقشه واقعی به جای SVG placeholder:

1. عکس نقشه ایران را با نام `iran-map.png` در این مسیر قرار دهید:
   ```
   frontend/public/images/iran-map.png
   ```

2. کامپوننت `IranMap.jsx` به صورت خودکار عکس را لود می‌کند.

---

## ⚠️ نکات مهم

- **بک‌اند و فرانت‌اند باید همزمان اجرا شوند.**
- **کلید API OpenWeatherMap الزامی است.**
- **برای تغییرات CSS، حتماً کش مرورگر را پاک کنید (Ctrl+F5).**
- **در صورت خطای PostCSS، پوشه `.next` و `node_modules` را حذف و دوباره `npm install` کنید.**

---

## 📝 لایسنس

این پروژه برای استفاده شخصی و آموزشی آزاد است.

---

<div align="center">
  <p>ساخته شده با ❤️ برای ایران</p>
</div>
