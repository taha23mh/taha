"use client";
import { useState } from "react";
import { toPersianNum } from "@/app/data";

const provinceCoords = {
  "تهران": { x: 48, y: 32 },
  "مشهد": { x: 62, y: 28 },
  "اصفهان": { x: 45, y: 52 },
  "تبریز": { x: 25, y: 18 },
  "شیراز": { x: 42, y: 68 },
  "اهواز": { x: 28, y: 62 },
  "کرمانشاه": { x: 22, y: 42 },
  "رشت": { x: 38, y: 22 },
  "زاهدان": { x: 72, y: 65 },
  "کرمان": { x: 58, y: 58 },
  "ارومیه": { x: 15, y: 20 },
  "سنندج": { x: 24, y: 38 },
  "گرگان": { x: 55, y: 22 },
  "همدان": { x: 32, y: 38 },
  "یزد": { x: 52, y: 48 },
  "اردبیل": { x: 22, y: 15 },
  "قزوین": { x: 38, y: 30 },
  "قم": { x: 44, y: 38 },
  "ساری": { x: 50, y: 24 },
  "بوشهر": { x: 35, y: 72 },
  "بندرعباس": { x: 58, y: 78 },
  "ایلام": { x: 18, y: 48 },
  "خرم‌آباد": { x: 28, y: 48 },
  "سمنان": { x: 52, y: 32 },
  "شهرکرد": { x: 36, y: 52 },
  "بیرجند": { x: 65, y: 48 },
  "یاسوج": { x: 32, y: 62 },
};

export default function IranMap({ provinces, currentCity, onSelectCity }) {
  const [hovered, setHovered] = useState(null);

  if (!provinces.length) {
    return (
      <div className="glass-card p-6 h-full min-h-[300px] flex items-center justify-center">
        <div className="w-full h-64 shimmer"></div>
      </div>
    );
  }

  return (
    <div className="glass-card p-6 h-full relative overflow-hidden">
      <h3 className="text-lg font-bold mb-4 flex items-center gap-2">
        <i className="fa-solid fa-map-location-dot text-amber-400"></i>
        نقشه تعاملی ایران
      </h3>
      <div className="relative w-full aspect-[4/3] bg-white/5 rounded-2xl overflow-hidden" style={{ border: "1px solid var(--glass-border)" }}>
        <svg viewBox="0 0 100 100" className="w-full h-full opacity-20" preserveAspectRatio="none">
          <path
            d="M20,15 L25,12 L35,10 L45,8 L55,10 L65,12 L75,15 L80,20 L85,30 L88,40 L90,50 L88,60 L85,70 L80,80 L75,85 L65,88 L55,90 L45,88 L35,85 L25,80 L20,75 L15,65 L12,55 L10,45 L12,35 L15,25 Z"
            fill="currentColor"
            className="text-slate-400"
          />
        </svg>
        {provinces.map((p) => {
          const coord = provinceCoords[p.capital];
          if (!coord) return null;
          const isActive = currentCity === p.capital;
          return (
            <button
              key={p.id}
              className="map-group"
              style={{ left: `${coord.x}%`, top: `${coord.y}%` }}
              onClick={() => onSelectCity(p.capital, p)}
              onMouseEnter={() => setHovered(p.capital)}
              onMouseLeave={() => setHovered(null)}
            >
              <div className={`map-dot ${isActive ? "active" : ""}`}>
                {isActive && <span className="pulse-ring" style={{ color: "#f5b942" }}></span>}
              </div>
              {(hovered === p.capital || isActive) && (
                <div className="map-label">
                  <span className="font-bold">{p.capital}</span>
                </div>
              )}
            </button>
          );
        })}
      </div>
      <p className="text-xs mt-3 text-center" style={{ color: "var(--text-muted)" }}>
        روی نقاط برای مشاهده آب و هوا کلیک کنید
      </p>
    </div>
  );
}
