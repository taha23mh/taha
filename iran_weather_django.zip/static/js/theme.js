/* Theme Toggle, Clock, and Hourly Slider - Pure UI, NO API calls */

// ========== Clock ==========
const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
function toPersianNum(num) {
    return num.toString().replace(/\d/g, d => persianDigits[d]);
}

function updateClock() {
    const now = new Date();
    const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    const el = document.getElementById('clock-time');
    if (el) el.textContent = toPersianNum(time);
}
setInterval(updateClock, 1000);
updateClock();

// ========== Theme Toggle ==========
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');
const header = document.getElementById('main-header');

function toggleTheme() {
    const html = document.documentElement;
    const current = html.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);

    if (themeIcon) {
        themeIcon.className = `fa-solid ${next === 'dark' ? 'fa-moon' : 'fa-sun'} text-amber-400`;
    }
    if (header) {
        header.style.background = next === 'dark' ? 'rgba(10, 17, 40, 0.7)' : 'rgba(255, 255, 255, 0.85)';
    }

    // Save preference
    localStorage.setItem('theme', next);
}

if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
}

// Load saved theme
const savedTheme = localStorage.getItem('theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);
if (themeIcon) {
    themeIcon.className = `fa-solid ${savedTheme === 'dark' ? 'fa-moon' : 'fa-sun'} text-amber-400`;
}
if (header) {
    header.style.background = savedTheme === 'dark' ? 'rgba(10, 17, 40, 0.7)' : 'rgba(255, 255, 255, 0.85)';
}

// ========== Hourly Slider Drag ==========
const slider = document.getElementById('hourly-slider');
if (slider) {
    let isDown = false;
    let startX, scrollLeft;

    slider.addEventListener('mousedown', (e) => {
        isDown = true;
        slider.classList.add('drag-active');
        startX = e.pageX - slider.offsetLeft;
        scrollLeft = slider.scrollLeft;
    });
    slider.addEventListener('mouseleave', () => {
        isDown = false;
        slider.classList.remove('drag-active');
    });
    slider.addEventListener('mouseup', () => {
        isDown = false;
        slider.classList.remove('drag-active');
    });
    slider.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - slider.offsetLeft;
        const walk = (x - startX) * 2;
        slider.scrollLeft = scrollLeft - walk;
    });
}

// ========== Search Form Auto-submit on Enter ==========
const searchInput = document.getElementById('search-input');
if (searchInput) {
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            document.getElementById('search-form').submit();
        }
    });
}
