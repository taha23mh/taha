from django.shortcuts import render, redirect
from django.contrib import messages
from .utils import (
    fetch_weather_data,
    get_province_by_capital,
    process_forecast_data,
    search_provinces,
    to_persian_num,
    get_weather_type,
    deg_to_compass,
    PROVINCES_DATA,
)


def weather_home(request):
    """Main weather view - server-side rendered."""

    # Get city from GET parameter or POST form
    city = request.GET.get('city', '') or request.POST.get('city', '')

    # If no city provided, default to Tehran
    if not city:
        city = 'تهران'

    # Search handling (from search form)
    search_query = request.POST.get('search', '')
    search_results = []
    if search_query:
        search_results = search_provinces(search_query)
        if len(search_results) == 1:
            # Auto-select if only one result
            city = search_results[0]['city']
            search_results = []

    # Fetch weather data from API
    weather_response = fetch_weather_data(city)
    current = weather_response['current']
    forecast_list = weather_response['forecast']
    error = weather_response['error']

    # Get province info
    province = get_province_by_capital(city)

    # Process forecast data
    forecast_data = process_forecast_data(forecast_list) if forecast_list else {'daily': [], 'hourly': []}

    # Prepare weather type info for current weather
    weather_type = None
    if current:
        weather_type = get_weather_type(current['weather'][0]['icon'])

    # Prepare extra info
    extra_info = None
    if current:
        from datetime import datetime
        sunrise = datetime.fromtimestamp(current['sys']['sunrise'])
        sunset = datetime.fromtimestamp(current['sys']['sunset'])
        extra_info = {
            'sunrise_hour': to_persian_num(f"{sunrise.hour:02d}"),
            'sunrise_min': to_persian_num(f"{sunrise.minute:02d}"),
            'sunset_hour': to_persian_num(f"{sunset.hour:02d}"),
            'sunset_min': to_persian_num(f"{sunset.minute:02d}"),
            'description': current['weather'][0]['description'],
            'lat': to_persian_num(current['coord']['lat']),
            'lon': to_persian_num(current['coord']['lon']),
        }

    # Prepare quick info
    quick_info = None
    if current:
        quick_info = {
            'humidity': current['main']['humidity'],
            'humidity_persian': to_persian_num(current['main']['humidity']),
            'wind_speed': to_persian_num(current['wind']['speed']),
            'wind_dir': deg_to_compass(current['wind']['deg']),
            'pressure': to_persian_num(current['main']['pressure']),
            'visibility': to_persian_num(round(current['visibility'] / 1000, 1)),
            'clouds': current['clouds']['all'],
            'clouds_persian': to_persian_num(current['clouds']['all']),
        }

    # Prepare current weather card data
    weather_card = None
    if current:
        weather_card = {
            'city': current['name'],
            'province_name': province['name'],
            'description': current['weather'][0]['description'],
            'temp': to_persian_num(round(current['main']['temp'])),
            'feels_like': to_persian_num(round(current['main']['feels_like'])),
            'temp_max': to_persian_num(round(current['main']['temp_max'])),
            'temp_min': to_persian_num(round(current['main']['temp_min'])),
            'icon': weather_type['icon'],
            'icon_color': weather_type['color'],
            'summary': f"وضعیت هوا: {current['weather'][0]['description']}. دمای فعلی {to_persian_num(round(current['main']['temp']))} درجه سانتی‌گراد است.",
        }

    # Process daily forecast with Persian numbers
    daily_forecast = []
    for day in forecast_data['daily']:
        wt = get_weather_type(day['icon'])
        daily_forecast.append({
            'is_today': day['is_today'],
            'day_name': 'امروز' if day['is_today'] else day['day_name'],
            'day_num': to_persian_num(day['day_num']),
            'month_num': to_persian_num(day['month_num']),
            'temp_max': to_persian_num(round(day['temp_max'])),
            'temp_min': to_persian_num(round(day['temp_min'])),
            'icon': wt['icon'],
            'icon_color': wt['color'],
            'description': day['description'],
        })

    # Process hourly forecast with Persian numbers
    hourly_forecast = []
    for hour in forecast_data['hourly']:
        wt = get_weather_type(hour['icon'])
        hourly_forecast.append({
            'is_now': hour['is_now'],
            'time_label': 'اکنون' if hour['is_now'] else f"{to_persian_num(f'{hour['hour']:02d}')}:۰۰",
            'temp': to_persian_num(hour['temp']),
            'icon': wt['icon'],
            'icon_color': wt['color'],
        })

    context = {
        'city': city,
        'province': province,
        'weather_card': weather_card,
        'quick_info': quick_info,
        'extra_info': extra_info,
        'daily_forecast': daily_forecast,
        'hourly_forecast': hourly_forecast,
        'search_results': search_results,
        'search_query': search_query,
        'error': error,
        'loading': not current and not error,
    }

    return render(request, 'index.html', context)
