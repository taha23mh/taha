from .utils import PROVINCES_DATA, to_persian_num
from django.utils import timezone


def provinces_data_processor(request):
    """Inject provinces data and current time into all templates."""
    now = timezone.now()
    return {
        'provinces_data': PROVINCES_DATA,
        'current_time': now,
    }
