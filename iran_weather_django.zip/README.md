# هواشناسی ایران - Django Template

پروژه پیش‌بینی آب و هوای شهرهای ایران با **Django Web Templates** (Server-Side Rendering).

## ویژگی‌ها

- **Server-Side Rendering**: تمام دیتا سمت سرور پردازش و رندر می‌شود
- **بدون DRF**: فقط Django Templates + Views معمولی
- **بدون API Call سمت کلاینت**: همه درخواست‌ها به OpenWeatherMap از سمت سرور Django انجام می‌شود
- **Dark/Light Mode**: با ذخیره‌سازی در localStorage
- **نقشه تعاملی**: کلیک روی نقاط استان‌ها
- **جستجوی شهر**: فرم POST ساده
- **پیش‌بینی ۵ روزه و ساعتی**

## نصب و راه‌اندازی

```bash
# 1. Clone or extract project
cd iran_weather_django

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate  # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set API Key (required!)
# Edit iran_weather/settings.py and set your OpenWeatherMap API key:
# OPENWEATHER_API_KEY = 'your-api-key-here'
# OR set environment variable:
export OPENWEATHER_API_KEY="your-api-key-here"

# 5. Run migrations
python manage.py migrate

# 6. Add map.jpg
# Copy your map.jpg file to static/images/map.jpg

# 7. Run server
python manage.py runserver

# 8. Open browser
http://127.0.0.1:8000
```

## ساختار پروژه

```
iran_weather_django/
├── iran_weather/          # Project settings
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── weather_app/           # Main app
│   ├── views.py           # Server-side weather fetching
│   ├── utils.py           # Helpers & data
│   ├── context_processors.py
│   └── urls.py
├── templates/             # Django Templates
│   ├── base.html
│   ├── index.html
│   └── includes/
│       ├── header.html
│       ├── search_bar.html
│       ├── weather_card.html
│       ├── quick_info.html
│       ├── iran_map.html
│       ├── provinces_list.html
│       ├── forecast.html
│       ├── hourly_forecast.html
│       └── extra_info.html
├── static/                # CSS, JS, Images
│   ├── css/style.css
│   ├── js/theme.js
│   └── images/map.jpg
├── manage.py
└── requirements.txt
```

## نکات مهم

1. **API Key**: حتماً کلید OpenWeatherMap خودتون رو در `settings.py` یا متغیر محیطی `OPENWEATHER_API_KEY` تنظیم کنید.
2. **map.jpg**: فایل نقشه ایران رو باید خودتون به `static/images/map.jpg` اضافه کنید.
3. **بدون npm/build**: این پروژه هیچ وابستگی به Node.js یا Tailwind build ندارد. CSS خالص است.
4. **City Selection**: با کلیک روی نقشه یا لیست استان‌ها، پارامتر `?city=NAME` به URL اضافه می‌شود.
5. **Search**: فرم جستجو با POST به View ارسال می‌شود و نتایج سمت سرور فیلتر می‌شود.
