'use client';
import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { normalizeFa } from '@/app/data';

export default function SearchBar({ provinces, onSelectCity }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const containerRef = useRef(null);

  useEffect(() => {
    if (!query.trim()) { setResults([]); setShowDropdown(false); return; }
    const nq = normalizeFa(query.trim());
    const res = [];
    provinces.forEach(p => {
      if (normalizeFa(p.name).includes(nq) || normalizeFa(p.capital).includes(nq))
        res.push({ city: p.capital, province: p, isCapital: true });
      p.cities?.forEach(c => {
        if (normalizeFa(c.name).includes(nq) && c.name !== p.capital)
          res.push({ city: c.name, province: p, isCapital: false });
      });
    });
    setResults(res.slice(0, 10));
    setShowDropdown(true);
  }, [query, provinces]);

  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) setShowDropdown(false);
    };
    document.addEventListener('click', handler);
    return () => document.removeEventListener('click', handler);
  }, []);

  return (
    <section className="mb-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl sm:text-5xl font-bold mb-3">
          آب و هوای <span className="temp-gradient">ایران</span> را کشف کنید
        </h2>
      </div>
      <div ref={containerRef} className="relative max-w-2xl mx-auto">
        <i className="fa-solid fa-magnifying-glass absolute right-5 top-1/2 -translate-y-1/2 text-slate-400"></i>
        <input
          type="text" value={query} onChange={(e) => setQuery(e.target.value)}
          placeholder="نام شهر یا استان..."
          className="search-input w-full rounded-2xl py-4 pr-12 pl-10 text-sm sm:text-base"
        />
        {showDropdown && (
          <div className="absolute top-full mt-2 w-full rounded-2xl shadow-2xl overflow-hidden z-[100] max-h-80 overflow-y-auto"
               style={{ background: 'var(--bg-mid)', border: '1px solid var(--glass-border)' }}>
            {results.length === 0 ? (
              <div className="p-4 text-center text-sm" style={{ color: 'var(--text-muted)' }}>نتیجه‌ای یافت نشد</div>
            ) : (
              results.map((r, i) => (
                <div key={i} className="dropdown-item p-3 flex items-center justify-between cursor-pointer">
                  <Link href={`/city/${encodeURIComponent(r.city)}`} className="flex items-center gap-3 flex-1">
                    <i className={`fa-solid ${r.isCapital ? 'fa-city' : 'fa-map-pin'} text-amber-400`}></i>
                    <div>
                      <p className="text-sm font-medium">{r.city}</p>
                      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>استان {r.province.name}</p>
                    </div>
                  </Link>
                  <button onClick={() => onSelectCity(r.city, r.province)} className="text-xs text-amber-400 hover:underline ml-2">
                    نمایش در داشبورد
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </section>
  );
}
