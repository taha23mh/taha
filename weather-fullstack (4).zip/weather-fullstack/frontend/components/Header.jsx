'use client';
import { useState, useEffect } from 'react';
import { toPersianNum } from '@/app/data';

export default function Header({ theme, onToggleTheme }) {
  const [time, setTime] = useState('--:--:--');

  useEffect(() => {
    const update = () => {
      const now = new Date();
      setTime(
        `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`
      );
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header
      className="sticky top-0 z-50 backdrop-blur-xl border-b"
      style={{
        background: theme === 'dark' ? 'rgba(10, 17, 40, 0.7)' : 'rgba(255, 255, 255, 0.85)',
        borderColor: 'var(--glass-border)'
      }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center shadow-lg shadow-amber-500/30">
            <i className="fa-solid fa-cloud-sun text-white text-xl"></i>
          </div>
          <div>
            <h1 className="text-lg sm:text-xl font-bold leading-tight">هواشناسی ایران</h1>
            <p className="text-xs hidden sm:block" style={{ color: 'var(--text-muted)' }}>
              پیش‌بینی دقیق آب و هوای شهرهای ایران
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div
            className="hidden md:flex items-center gap-2 text-xs px-3 py-2 rounded-xl"
            style={{ background: 'var(--input-bg)', border: '1px solid var(--glass-border)', color: 'var(--text-muted)' }}
          >
            <i className="fa-regular fa-clock"></i>
            <span>{toPersianNum(time)}</span>
          </div>

          <button
            onClick={onToggleTheme}
            className="w-10 h-10 rounded-xl flex items-center justify-center transition hover:bg-white/10"
            style={{ background: 'var(--input-bg)', border: '1px solid var(--glass-border)' }}
          >
            <i className={`fa-solid ${theme === 'dark' ? 'fa-moon' : 'fa-sun'} text-amber-400`}></i>
          </button>
        </div>
      </div>
    </header>
  );
}
