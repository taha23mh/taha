'use client';
import { toPersianNum, degToCompass } from '@/app/data';

export default function QuickInfo({ weather, loading }) {
  if (loading && !weather) {
    return <div className="glass-card p-6 text-center text-amber-400 h-full">در حال بارگذاری...</div>;
  }
  if (!weather) return null;

  return (
    <div className="glass-card p-6 h-full">
      <h4 className="text-sm font-semibold mb-4 flex items-center gap-2" style={{ color: 'var(--text-soft)' }}>
        <i className="fa-solid fa-chart-line text-amber-400"></i>
        اطلاعات لحظه‌ای
      </h4>

      <div className="space-y-3">
        <div className="info-card p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-muted)' }}>
              <i className="fa-solid fa-droplet text-sky-400"></i><span>رطوبت</span>
            </div>
            <span className="text-lg font-bold">{toPersianNum(weather.main.humidity)}%</span>
          </div>
          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-sky-500 to-sky-300 rounded-full transition-all duration-700" style={{ width: `${weather.main.humidity}%` }} />
          </div>
        </div>

        <div className="info-card p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-muted)' }}>
              <i className="fa-solid fa-wind text-emerald-400"></i><span>سرعت باد</span>
            </div>
            <span className="text-lg font-bold">{toPersianNum(weather.wind.speed)} m/s</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span style={{ color: 'var(--text-muted)' }}>جهت:</span>
            <span style={{ color: 'var(--text-soft)' }}>{degToCompass(weather.wind.deg)}</span>
          </div>
        </div>

        <div className="info-card p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-muted)' }}>
              <i className="fa-solid fa-gauge text-purple-400"></i><span>فشار هوا</span>
            </div>
            <span className="text-lg font-bold">{toPersianNum(weather.main.pressure)} hPa</span>
          </div>
          <div className="flex items-center justify-between text-xs">
            <span style={{ color: 'var(--text-muted)' }}>دید:</span>
            <span style={{ color: 'var(--text-soft)' }}>{toPersianNum((weather.visibility / 1000).toFixed(1))} km</span>
          </div>
        </div>

        <div className="info-card p-4">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2 text-xs" style={{ color: 'var(--text-muted)' }}>
              <i className="fa-solid fa-cloud text-slate-400"></i><span>میزان ابر</span>
            </div>
            <span className="text-lg font-bold">{toPersianNum(weather.clouds.all)}%</span>
          </div>
          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-slate-500 to-slate-300 rounded-full transition-all duration-700" style={{ width: `${weather.clouds.all}%` }} />
          </div>
        </div>
      </div>
    </div>
  );
}
