'use client';
export default function ProvincesList({ provinces, currentCity, onSelectCity }) {
  return (
    <div className="glass-card p-6 h-full">
      <h4 className="text-base font-semibold flex items-center gap-2 mb-4">
        <i className="fa-solid fa-list text-amber-400"></i> استان‌های ایران
      </h4>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[662px] overflow-y-auto pl-2">
        {provinces.map(p => (
          <button
            key={p.id}
            onClick={() => onSelectCity(p.capital, p)}
            className={`province-btn p-3 ${currentCity === p.capital ? 'active' : ''}`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-medium text-sm">{p.name}</span>
              <i className="fa-solid fa-location-dot text-amber-400 text-xs"></i>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span style={{ color: 'var(--text-muted)' }}>مرکز: {p.capital}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
