'use client';
import { toPersianNum } from '@/app/data';

export default function ExtraInfo({ weather, loading }) {
  if (loading && !weather) {
    return (
      <section className="mb-8">
        <div className="glass-card p-6 text-center text-amber-400">در حال بارگذاری...</div>
      </section>
    );
  }
  if (!weather) return null;

  const sunrise = new Date(weather.sys.sunrise * 1000);
  const sunset = new Date(weather.sys.sunset * 1000);

  return (
    <section className="mb-8 grid grid-cols-2 lg:grid-cols-4 gap-4">
      <div className="info-card glass-card p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>طلوع آفتاب</span>
          <i className="fa-solid fa-sun text-amber-400 text-xl"></i>
        </div>
        <p className="text-xl sm:text-2xl font-bold">
          {toPersianNum(sunrise.getHours().toString().padStart(2, '0'))}:{toPersianNum(sunrise.getMinutes().toString().padStart(2, '0'))}
        </p>
      </div>

      <div className="info-card glass-card p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>غروب آفتاب</span>
          <i className="fa-solid fa-moon text-purple-400 text-xl"></i>
        </div>
        <p className="text-xl sm:text-2xl font-bold">
          {toPersianNum(sunset.getHours().toString().padStart(2, '0'))}:{toPersianNum(sunset.getMinutes().toString().padStart(2, '0'))}
        </p>
      </div>

      <div className="info-card glass-card p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>وضعیت هوا</span>
          <i className="fa-solid fa-cloud-sun text-sky-400 text-xl"></i>
        </div>
        <p className="text-sm font-bold">{weather.weather[0].description}</p>
      </div>

      <div className="info-card glass-card p-5">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs" style={{ color: 'var(--text-muted)' }}>مختصات</span>
          <i className="fa-solid fa-location-crosshairs text-rose-400 text-xl"></i>
        </div>
        <p className="text-sm font-bold">
          {toPersianNum(weather.coord.lat)} / {toPersianNum(weather.coord.lon)}
        </p>
      </div>
    </section>
  );
}
