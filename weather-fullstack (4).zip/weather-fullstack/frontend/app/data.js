export const weatherTypes = {
  '01d': { name: 'آفتابی', icon: 'fa-sun', color: '#f5b942' },
  '01n': { name: 'آفتابی', icon: 'fa-sun', color: '#f5b942' },
  '02d': { name: 'نیمه ابری', icon: 'fa-cloud-sun', color: '#9bb8d9' },
  '02n': { name: 'نیمه ابری', icon: 'fa-cloud-moon', color: '#9bb8d9' },
  '03d': { name: 'ابری', icon: 'fa-cloud', color: '#8b92b8' },
  '03n': { name: 'ابری', icon: 'fa-cloud', color: '#8b92b8' },
  '04d': { name: 'ابری', icon: 'fa-cloud', color: '#8b92b8' },
  '04n': { name: 'ابری', icon: 'fa-cloud', color: '#8b92b8' },
  '09d': { name: 'بارانی', icon: 'fa-cloud-rain', color: '#4fc3f7' },
  '09n': { name: 'بارانی', icon: 'fa-cloud-rain', color: '#4fc3f7' },
  '10d': { name: 'بارانی', icon: 'fa-cloud-rain', color: '#4fc3f7' },
  '10n': { name: 'بارانی', icon: 'fa-cloud-moon-rain', color: '#4fc3f7' },
  '11d': { name: 'رعد و برق', icon: 'fa-cloud-bolt', color: '#9b6dff' },
  '11n': { name: 'رعد و برق', icon: 'fa-cloud-bolt', color: '#9b6dff' },
  '13d': { name: 'برفی', icon: 'fa-snowflake', color: '#e0f4ff' },
  '13n': { name: 'برفی', icon: 'fa-snowflake', color: '#e0f4ff' },
  '50d': { name: 'مه‌آلود', icon: 'fa-smog', color: '#b8bfd9' },
  '50n': { name: 'مه‌آلود', icon: 'fa-smog', color: '#b8bfd9' }
};

export const windDirections = ['شمال', 'شمال شرق', 'شرق', 'جنوب شرق', 'جنوب', 'جنوب غرب', 'غرب', 'شمال غرب'];
export const dayNames = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];

export const toPersianNum = (num) => num.toString().replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);

export const normalizeFa = (text) =>
  text.replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/أ/g, 'ا').replace(/إ/g, 'ا').replace(/ؤ/g, 'و').replace(/ئ/g, 'ی');

export const getWeatherType = (iconCode) => weatherTypes[iconCode] || weatherTypes['01d'];

export const degToCompass = (deg) => {
  const val = Math.floor((deg / 45) + 0.5);
  return windDirections[(val % 8)];
};
