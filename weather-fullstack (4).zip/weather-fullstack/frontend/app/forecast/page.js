'use client';
import { useState, useEffect } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Forecast from '@/components/Forecast';
import { fetchCityForecast, fetchProvinces } from '@/lib/api';

export default function ForecastPage() {
  const [city, setCity] = useState('تهران');
  const [forecast, setForecast] = useState([]);
  const [provinces, setProvinces] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProvinces().then(setProvinces);
    fetchCityForecast(city).then(f => {
      setForecast(f.list);
      setLoading(false);
    });
  }, [city]);

  return (
    <div className="pb-10 min-h-screen bg-gradient-main">
      <Header theme="dark" onToggleTheme={() => {}} />
      <main className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center gap-2 mb-6 text-sm" style={{ color: 'var(--text-muted)' }}>
          <Link href="/" className="hover:text-amber-400 transition">← بازگشت</Link>
        </div>
        <div className="glass-card p-6 mb-8">
          <h2 className="text-2xl font-bold mb-4">🌤 پیش‌بینی ۵ روزه</h2>
          <div className="flex flex-wrap gap-2">
            {provinces.map(p => (
              <button
                key={p.id}
                onClick={() => { setCity(p.capital); setLoading(true); }}
                className={`province-btn px-4 py-2 text-sm ${city === p.capital ? 'active' : ''}`}
              >
                {p.capital}
              </button>
            ))}
          </div>
        </div>
        <Forecast forecast={forecast} loading={loading} />
      </main>
    </div>
  );
}
