from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Province, City
from .serializers import ProvinceSerializer, CitySerializer
from .utils import fetch_weather

class ProvinceViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Province.objects.prefetch_related('cities').all()
    serializer_class = ProvinceSerializer

    @action(detail=True, methods=['get'])
    def weather(self, request, pk=None):
        province = self.get_object()
        try:
            data = fetch_weather(province.capital, 'weather')
            return Response(data)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

class CityViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = City.objects.select_related('province').all()
    serializer_class = CitySerializer
    lookup_field = 'name'

    @action(detail=True, methods=['get'])
    def weather(self, request, name=None):
        try:
            data = fetch_weather(name, 'weather')
            return Response(data)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)

    @action(detail=True, methods=['get'])
    def forecast(self, request, name=None):
        try:
            data = fetch_weather(name, 'forecast')
            return Response(data)
        except Exception as e:
            return Response({'error': str(e)}, status=status.HTTP_503_SERVICE_UNAVAILABLE)
