// ========== All Provinces Data (Frontend) ==========
const provincesData = [
  { id: 1, name: "آذربایجان شرقی", capital: "تبریز", cities: ["تبریز","مراغه","میانه","بناب","اهر","سراب","مرند","شبستر"], x: 10, y: 11, lat: 38.08 },
  { id: 2, name: "آذربایجان غربی", capital: "ارومیه", cities: ["ارومیه","خوی","سلماس","ماکو","مهاباد","بوکان","نقده","پیرانشهر"], x: 12, y: 20, lat: 37.55 },
  { id: 3, name: "اردبیل", capital: "اردبیل", cities: ["اردبیل","پارس‌آباد","مشگین‌شهر","خلخال","گرمی","بیله‌سوار"], x: 20, y: 14, lat: 38.25 },
  { id: 4, name: "اصفهان", capital: "اصفهان", cities: ["اصفهان","کاشان","نائین","نجف‌آباد","شاهین‌شهر","فولادشهر","زرین‌شهر"], x: 48, y: 40, lat: 32.65 },
  { id: 5, name: "البرز", capital: "کرج", cities: ["کرج","نظرآباد","اشتهارد","فردیس","محمدشهر","هشتگرد","ماهدشت"], x: 35, y: 29, lat: 35.92 },
  { id: 6, name: "ایلام", capital: "ایلام", cities: ["ایلام","دهلران","آبدانان","مهران","ایوان","دره‌شهر","آسمان‌آباد"], x: 13, y: 44, lat: 33.64 },
  { id: 7, name: "بوشهر", capital: "بوشهر", cities: ["بوشهر","برازجان","گناوه","خارک","دیلم","کنگان","جم","عسلویه"], x: 35, y: 72, lat: 28.95 },
  { id: 8, name: "تهران", capital: "تهران", cities: ["تهران","ورامین","شهریار","پاکدشت","رباط‌کریم","اسلام‌شهر","قدس","ملارد"], x: 40, y: 30, lat: 35.69 },
  { id: 9, name: "چهارمحال و بختیاری", capital: "شهرکرد", cities: ["شهرکرد","فارسان","بروجن","لردگان","سامان","اردل","بن","کوهرنگ"], x: 35, y: 53, lat: 32.33 },
  { id: 10, name: "خراسان جنوبی", capital: "بیرجند", cities: ["بیرجند","قاین","فردوس","نهبندان","طبس","سرایان","خوسف"], x: 73, y: 48, lat: 32.87 },
  { id: 11, name: "خراسان رضوی", capital: "مشهد", cities: ["مشهد","نیشابور","سبزوار","تربت حیدریه","کاشمر","تربت جام","چناران","قوچان"], x: 73, y: 25, lat: 36.30 },
  { id: 12, name: "خراسان شمالی", capital: "بجنورد", cities: ["بجنورد","اسفراین","شیروان","آشخانه","جاجرم","پیش‌قلعه"], x: 64, y: 18, lat: 37.47 },
  { id: 13, name: "خوزستان", capital: "اهواز", cities: ["اهواز","آبادان","خرمشهر","دزفول","مسجدسلیمان","بهبهان","اندیمشک","شوشتر"], x: 25, y: 56, lat: 31.32 },
  { id: 14, name: "زنجان", capital: "زنجان", cities: ["زنجان","ابهر","خرمدره","قیدار","طارم","ماه‌نشان","سلطانیه"], x: 20, y: 25, lat: 36.67 },
  { id: 15, name: "سمنان", capital: "سمنان", cities: ["سمنان","شاهرود","دامغان","گرمسار","مهدی‌شهر","ایوانکی"], x: 58, y: 30, lat: 35.58 },
  { id: 16, name: "سیستان و بلوچستان", capital: "زاهدان", cities: ["زاهدان","زابل","چابهار","ایرانشهر","خاش","سراوان","نیک‌شهر","کنارک"], x: 80, y: 80, lat: 29.50 },
  { id: 17, name: "فارس", capital: "شیراز", cities: ["شیراز","مرودشت","جهرم","کازرون","فسا","داراب","لار","استهبان"], x: 45, y: 66, lat: 29.62 },
  { id: 18, name: "قزوین", capital: "قزوین", cities: ["قزوین","تاکستان","آبیک","بوئین‌زهرا","محمدیه","الوند","محمودآباد نمونه"], x: 28, y: 28, lat: 36.27 },
  { id: 19, name: "قم", capital: "قم", cities: ["قم","قنوات","کهک","جعفریه","سلفچگان"], x: 35, y: 35, lat: 34.65 },
  { id: 20, name: "کردستان", capital: "سنندج", cities: ["سنندج","مریوان","سقز","بانه","قروه","بیجار","دیواندره","کامیاران"], x: 15, y: 28, lat: 35.31 },
  { id: 21, name: "کرمان", capital: "کرمان", cities: ["کرمان","سیرجان","رفسنجان","جیرفت","بم","زرند","بافت","کهنوج"], x: 65, y: 63, lat: 30.28 },
  { id: 22, name: "کرمانشاه", capital: "کرمانشاه", cities: ["کرمانشاه","اسلام‌آباد غرب","سنقر","صحنه","هرسین","کنگاور","صاحب","قصر شیرین"], x: 13, y: 35, lat: 34.32 },
  { id: 23, name: "کهگیلویه و بویراحمد", capital: "یاسوج", cities: ["یاسوج","گچساران","دهدشت","سی‌سخت","لیکک","چرام","باشت"], x: 38, y: 61, lat: 30.67 },
  { id: 24, name: "گلستان", capital: "گرگان", cities: ["گرگان","گنبد کاووس","آق‌قلا","بندر ترکمن","علی‌آباد کتول","کلاله","مینودشت","آزادشهر"], x: 55, y: 18, lat: 36.85 },
  { id: 25, name: "گیلان", capital: "رشت", cities: ["رشت","بندر انزلی","لاهیجان","صومعه‌سرا","رودبار","آستارا","تالش","لنگرود"], x: 30, y: 22, lat: 37.28 },
  { id: 26, name: "لرستان", capital: "خرم‌آباد", cities: ["خرم‌آباد","بروجرد","دورود","الیگودرز","کوهدشت","ازنا","الشتر","نورآباد"], x: 25, y: 47, lat: 33.49 },
  { id: 27, name: "مازندران", capital: "ساری", cities: ["ساری","بابل","آمل","قائم‌شهر","نوشهر","تنکابن","بهشهر","نکا"], x: 43, y: 23, lat: 36.56 },
  { id: 28, name: "مرکزی", capital: "اراک", cities: ["اراک","ساوه","خمین","محلات","تفرش","دلیجان","آشتیان","شازند"], x: 28, y: 38, lat: 34.10 },
  { id: 29, name: "هرمزگان", capital: "بندرعباس", cities: ["بندرعباس","میناب","قشم","بندر لنگه","کیش","حاجی‌آباد","رودان","بستک"], x: 58, y: 82, lat: 27.18 },
  { id: 30, name: "همدان", capital: "همدان", cities: ["همدان","نهاوند","ملایر","تویسرکان","اسدآباد","بهار","کبودرآهنگ","رزن"], x: 22, y: 34, lat: 34.80 },
  { id: 31, name: "یزد", capital: "یزد", cities: ["یزد","میبد","اردکان","بافق","تفت","مهریز","ابرکوه","خاتم"], x: 58, y: 52, lat: 31.90 },
];

// ========== Helpers ==========
const persianDigits = '۰۱۲۳۴۵۶۷۸۹';
function toPersianNum(num) {
    return num.toString().replace(/\d/g, d => persianDigits[d]);
}

function normalizeFa(text) {
    return text.replace(/ي/g, 'ی').replace(/ك/g, 'ک').replace(/أ/g, 'ا').replace(/إ/g, 'ا').replace(/ؤ/g, 'و').replace(/ئ/g, 'ی');
}

// ========== Clock ==========
function updateClock() {
    const now = new Date();
    const time = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}:${now.getSeconds().toString().padStart(2, '0')}`;
    const el = document.getElementById('clock-time');
    if (el) el.textContent = toPersianNum(time);
}
setInterval(updateClock, 1000);
updateClock();

// ========== Theme Toggle ==========
const themeToggle = document.getElementById('theme-toggle');
const themeIcon = document.getElementById('theme-icon');
const header = document.getElementById('main-header');

function toggleTheme() {
    const html = document.documentElement;
    const current = html.getAttribute('data-theme') || 'dark';
    const next = current === 'dark' ? 'light' : 'dark';
    html.setAttribute('data-theme', next);

    if (themeIcon) {
        themeIcon.className = `fa-solid ${next === 'dark' ? 'fa-moon' : 'fa-sun'} text-amber-400`;
    }
    if (header) {
        header.style.background = next === 'dark' ? 'rgba(10, 17, 40, 0.7)' : 'rgba(255, 255, 255, 0.85)';
    }
    localStorage.setItem('theme', next);
}

if (themeToggle) {
    themeToggle.addEventListener('click', toggleTheme);
}

const savedTheme = localStorage.getItem('theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);
if (themeIcon) {
    themeIcon.className = `fa-solid ${savedTheme === 'dark' ? 'fa-moon' : 'fa-sun'} text-amber-400`;
}
if (header) {
    header.style.background = savedTheme === 'dark' ? 'rgba(10, 17, 40, 0.7)' : 'rgba(255, 255, 255, 0.85)';
}

// ========== Hourly Slider Drag ==========
const slider = document.getElementById('hourly-slider');
if (slider) {
    let isDown = false;
    let startX, scrollLeft;

    slider.addEventListener('mousedown', (e) => {
        isDown = true;
        slider.classList.add('drag-active');
        startX = e.pageX - slider.offsetLeft;
        scrollLeft = slider.scrollLeft;
    });
    slider.addEventListener('mouseleave', () => {
        isDown = false;
        slider.classList.remove('drag-active');
    });
    slider.addEventListener('mouseup', () => {
        isDown = false;
        slider.classList.remove('drag-active');
    });
    slider.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - slider.offsetLeft;
        const walk = (x - startX) * 2;
        slider.scrollLeft = scrollLeft - walk;
    });
}

// ========== LIVE SEARCH (Pure Frontend - No Backend) ==========
const searchInput = document.getElementById('search-input');
const searchDropdown = document.getElementById('search-dropdown');
const searchResults = document.getElementById('search-results');
const searchClear = document.getElementById('search-clear');

let searchTimeout = null;

function searchProvinces(query) {
    if (!query) return [];
    const nq = normalizeFa(query.trim());
    const results = [];
    provincesData.forEach(p => {
        if (normalizeFa(p.name).includes(nq) || normalizeFa(p.capital).includes(nq)) {
            results.push({ city: p.capital, province: p.name, provinceId: p.id, isCapital: true });
        }
        p.cities.forEach(c => {
            if (normalizeFa(c).includes(nq) && c !== p.capital) {
                results.push({ city: c, province: p.name, provinceId: p.id, isCapital: false });
            }
        });
    });
    return results.slice(0, 10);
}

function renderSearchResults(results) {
    if (results.length === 0) {
        searchResults.innerHTML = '<div class="p-4 text-center text-sm" style="color: var(--text-muted)"><i class="fa-solid fa-circle-xmark text-rose-400 ml-2"></i>شهری با این نام یافت نشد</div>';
        return;
    }

    searchResults.innerHTML = results.map(r => `
        <a href="?city=${encodeURIComponent(r.city)}" class="dropdown-item block">
            <div class="flex items-center gap-3">
                <i class="fa-solid ${r.isCapital ? 'fa-city' : 'fa-map-pin'} text-amber-400"></i>
                <div>
                    <p class="text-sm font-medium">${r.city}</p>
                    <p class="text-xs" style="color: var(--text-muted)">استان ${r.province}</p>
                </div>
            </div>
            <i class="fa-solid fa-arrow-left text-slate-500 text-xs"></i>
        </a>
    `).join('');
}

if (searchInput) {
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim();

        if (searchClear) {
            searchClear.classList.toggle('hidden', !query);
        }

        if (!query) {
            searchDropdown.classList.add('hidden');
            return;
        }

        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            const results = searchProvinces(query);
            searchDropdown.classList.remove('hidden');
            renderSearchResults(results);
        }, 300);
    });

    if (searchClear) {
        searchClear.addEventListener('click', () => {
            searchInput.value = '';
            searchDropdown.classList.add('hidden');
            searchClear.classList.add('hidden');
            searchInput.focus();
        });
    }

    document.addEventListener('click', (e) => {
        if (!e.target.closest('#search-container')) {
            searchDropdown.classList.add('hidden');
        }
    });
}
